export function formatPrice(price: number): string {
  return new Intl.NumberFormat("fa-IR").format(price);
}

export function formatPriceToman(price: number): string {
  return `${formatPrice(price)} تومان`;
}

export function calculateDiscount(price: number, discountPrice: number | null): number {
  if (!discountPrice) return 0;
  return Math.round(((price - discountPrice) / price) * 100);
}

export function toFarsiNumber(num: number | string): string {
  const farsiDigits = ["۰", "۱", "۲", "۳", "۴", "۵", "۶", "۷", "۸", "۹"];
  return num.toString().replace(/[0-9]/g, (d) => farsiDigits[parseInt(d)]);
}

export function cn(...classes: (string | undefined | null | boolean)[]): string {
  return classes.filter(Boolean).join(" ");
}

export function generateStars(rating: number): string[] {
  const stars: string[] = [];
  for (let i = 1; i <= 5; i++) {
    if (i <= Math.floor(rating)) {
      stars.push("full");
    } else if (i - 0.5 <= rating) {
      stars.push("half");
    } else {
      stars.push("empty");
    }
  }
  return stars;
}
