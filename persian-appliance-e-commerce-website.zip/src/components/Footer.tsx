"use client";

import Link from "next/link";
import { COMPANY, CATEGORIES } from "@/lib/constants";
import { useState } from "react";

export default function Footer() {
  const [email, setEmail] = useState("");
  const [subscribed, setSubscribed] = useState(false);

  const handleSubscribe = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) return;
    try {
      await fetch("/api/newsletter", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email }),
      });
      setSubscribed(true);
      setEmail("");
    } catch { /* ignore */ }
  };

  return (
    <footer className="bg-gray-900 text-gray-300">
      {/* Newsletter */}
      <div className="border-b border-gray-800">
        <div className="max-w-7xl mx-auto px-4 py-12">
          <div className="bg-gradient-to-l from-blue-600 to-blue-800 rounded-2xl p-8 md:p-12 flex flex-col md:flex-row items-center justify-between gap-6">
            <div>
              <h3 className="text-xl md:text-2xl font-bold text-white mb-2">عضویت در خبرنامه</h3>
              <p className="text-blue-100 text-sm">از جدیدترین محصولات، تخفیف‌ها و اخبار پارس‌تک مطلع شوید</p>
            </div>
            <form onSubmit={handleSubscribe} className="flex w-full md:w-auto gap-2">
              {subscribed ? (
                <div className="bg-white/20 text-white px-6 py-3 rounded-xl text-sm font-medium">
                  ✓ با موفقیت ثبت شد
                </div>
              ) : (
                <>
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="ایمیل خود را وارد کنید"
                    className="flex-1 md:w-72 px-5 py-3 bg-white/10 border border-white/20 rounded-xl text-white placeholder-blue-200 text-sm focus:outline-none focus:ring-2 focus:ring-white/30"
                    dir="ltr"
                  />
                  <button type="submit" className="px-6 py-3 bg-white text-blue-700 font-bold text-sm rounded-xl hover:bg-blue-50 transition-colors whitespace-nowrap">
                    عضویت
                  </button>
                </>
              )}
            </form>
          </div>
        </div>
      </div>

      {/* Main Footer */}
      <div className="max-w-7xl mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 lg:gap-12">
          {/* Company Info */}
          <div>
            <div className="flex items-center gap-3 mb-6">
              <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-blue-700 rounded-xl flex items-center justify-center">
                <span className="text-white font-black text-lg">PT</span>
              </div>
              <div>
                <h3 className="text-white font-bold text-lg">{COMPANY.name}</h3>
                <p className="text-gray-500 text-xs">{COMPANY.slogan}</p>
              </div>
            </div>
            <p className="text-gray-400 text-sm leading-7 mb-6">
              شرکت صنعتی پارس‌تک از سال {COMPANY.year} فعالیت خود را در زمینه تولید لوازم خانگی آغاز کرده و اکنون یکی از بزرگ‌ترین تولیدکنندگان لوازم خانگی ایران است.
            </p>
            <div className="flex gap-3">
              <a href="#" className="w-9 h-9 bg-gray-800 hover:bg-blue-600 rounded-lg flex items-center justify-center transition-colors text-sm">📷</a>
              <a href="#" className="w-9 h-9 bg-gray-800 hover:bg-blue-600 rounded-lg flex items-center justify-center transition-colors text-sm">✈️</a>
              <a href="#" className="w-9 h-9 bg-gray-800 hover:bg-blue-600 rounded-lg flex items-center justify-center transition-colors text-sm">📱</a>
              <a href="#" className="w-9 h-9 bg-gray-800 hover:bg-blue-600 rounded-lg flex items-center justify-center transition-colors text-sm">🔗</a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-white font-bold text-base mb-6">دسترسی سریع</h4>
            <ul className="space-y-3">
              {[
                { href: "/about", label: "درباره ما" },
                { href: "/products", label: "محصولات" },
                { href: "/blog", label: "بلاگ و مقالات" },
                { href: "/contact", label: "تماس با ما" },
                { href: "/dealer", label: "درخواست نمایندگی" },
                { href: "/cooperation", label: "فرصت‌های شغلی" },
                { href: "/tracking", label: "پیگیری سفارش" },
                { href: "/warranty", label: "ثبت گارانتی" },
              ].map((link) => (
                <li key={link.href}>
                  <Link href={link.href} className="text-gray-400 hover:text-white text-sm transition-colors flex items-center gap-2">
                    <svg className="w-3 h-3 text-blue-500" fill="currentColor" viewBox="0 0 20 20"><path fillRule="evenodd" d="M12.707 5.293a1 1 0 010 1.414L9.414 10l3.293 3.293a1 1 0 01-1.414 1.414l-4-4a1 1 0 010-1.414l4-4a1 1 0 011.414 0z" clipRule="evenodd"/></svg>
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Categories */}
          <div>
            <h4 className="text-white font-bold text-base mb-6">دسته‌بندی محصولات</h4>
            <ul className="space-y-3">
              {CATEGORIES.slice(0, 8).map((cat) => (
                <li key={cat.id}>
                  <Link href={`/products?category=${cat.slug}`} className="text-gray-400 hover:text-white text-sm transition-colors flex items-center gap-2">
                    <span className="text-sm">{cat.icon}</span>
                    {cat.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4 className="text-white font-bold text-base mb-6">تماس با ما</h4>
            <div className="space-y-4">
              <div className="flex items-start gap-3">
                <div className="w-8 h-8 bg-gray-800 rounded-lg flex items-center justify-center flex-shrink-0 mt-0.5">
                  <svg className="w-4 h-4 text-blue-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"/><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"/></svg>
                </div>
                <p className="text-gray-400 text-sm leading-6">{COMPANY.address}</p>
              </div>
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 bg-gray-800 rounded-lg flex items-center justify-center flex-shrink-0">
                  <svg className="w-4 h-4 text-blue-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z"/></svg>
                </div>
                <span className="text-gray-400 text-sm">{COMPANY.phone}</span>
              </div>
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 bg-gray-800 rounded-lg flex items-center justify-center flex-shrink-0">
                  <svg className="w-4 h-4 text-blue-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"/></svg>
                </div>
                <span className="text-gray-400 text-sm" dir="ltr">{COMPANY.email}</span>
              </div>
            </div>

            {/* Trust badges */}
            <div className="mt-6 flex gap-3">
              <div className="w-16 h-16 bg-gray-800 rounded-xl flex items-center justify-center text-2xl">🏅</div>
              <div className="w-16 h-16 bg-gray-800 rounded-xl flex items-center justify-center text-2xl">✅</div>
              <div className="w-16 h-16 bg-gray-800 rounded-xl flex items-center justify-center text-2xl">🔒</div>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom */}
      <div className="border-t border-gray-800">
        <div className="max-w-7xl mx-auto px-4 py-6 flex flex-col md:flex-row items-center justify-between gap-4">
          <p className="text-gray-500 text-xs">
            © تمامی حقوق مادی و معنوی این وب‌سایت متعلق به شرکت صنعتی پارس‌تک می‌باشد. ۱۴۰۴
          </p>
          <div className="flex items-center gap-4 text-xs text-gray-500">
            <Link href="/privacy" className="hover:text-white transition-colors">حریم خصوصی</Link>
            <Link href="/terms" className="hover:text-white transition-colors">شرایط استفاده</Link>
            <Link href="/sitemap" className="hover:text-white transition-colors">نقشه سایت</Link>
          </div>
        </div>
      </div>
    </footer>
  );
}
