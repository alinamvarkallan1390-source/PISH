export default function SectionTitle({
  title,
  subtitle,
  centered = true,
  light = false,
}: {
  title: string;
  subtitle?: string;
  centered?: boolean;
  light?: boolean;
}) {
  return (
    <div className={`mb-10 md:mb-14 ${centered ? "text-center" : ""}`}>
      <h2 className={`text-2xl md:text-3xl lg:text-4xl font-black mb-3 ${light ? "text-white" : "text-gray-900"}`}>
        {title}
      </h2>
      {subtitle && (
        <p className={`text-sm md:text-base max-w-2xl ${centered ? "mx-auto" : ""} ${light ? "text-gray-300" : "text-gray-500"}`}>
          {subtitle}
        </p>
      )}
      <div className={`mt-4 w-20 h-1 bg-gradient-to-l from-blue-600 to-blue-400 rounded-full ${centered ? "mx-auto" : ""}`} />
    </div>
  );
}
