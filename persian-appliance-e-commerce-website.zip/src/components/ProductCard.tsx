"use client";

import Link from "next/link";
import { formatPriceToman, calculateDiscount, toFarsiNumber } from "@/lib/utils";

interface Product {
  id: number;
  name: string;
  slug: string;
  price: number;
  discountPrice: number | null;
  image: string;
  category: string;
  categorySlug: string;
  rating: number;
  reviewCount: number;
  stock: number;
  isNew: boolean;
  isBestSeller: boolean;
  discount: number;
  energyRating: string;
  color: string;
}

export default function ProductCard({ product }: { product: Product }) {
  const discount = calculateDiscount(product.price, product.discountPrice);

  return (
    <div className="group bg-white rounded-2xl border border-gray-100 overflow-hidden premium-card hover:border-blue-100">
      {/* Image */}
      <div className="relative aspect-[4/3] overflow-hidden bg-gray-50">
        <img
          src={product.image}
          alt={product.name}
          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
          loading="lazy"
        />
        
        {/* Badges */}
        <div className="absolute top-3 right-3 flex flex-col gap-2">
          {product.isNew && (
            <span className="px-2.5 py-1 bg-green-500 text-white text-[10px] font-bold rounded-lg shadow-sm">
              جدید
            </span>
          )}
          {product.isBestSeller && (
            <span className="px-2.5 py-1 bg-orange-500 text-white text-[10px] font-bold rounded-lg shadow-sm">
              پرفروش
            </span>
          )}
          {discount > 0 && (
            <span className="px-2.5 py-1 bg-red-500 text-white text-[10px] font-bold rounded-lg shadow-sm">
              {toFarsiNumber(discount)}% تخفیف
            </span>
          )}
        </div>

        {/* Quick Actions */}
        <div className="absolute bottom-3 left-3 flex flex-col gap-2 opacity-0 translate-y-2 group-hover:opacity-100 group-hover:translate-y-0 transition-all duration-300">
          <button className="w-9 h-9 bg-white/90 backdrop-blur-sm rounded-xl flex items-center justify-center text-gray-600 hover:text-red-500 hover:bg-red-50 transition-colors shadow-sm" title="افزودن به علاقه‌مندی‌ها">
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z"/></svg>
          </button>
          <button className="w-9 h-9 bg-white/90 backdrop-blur-sm rounded-xl flex items-center justify-center text-gray-600 hover:text-blue-600 hover:bg-blue-50 transition-colors shadow-sm" title="مقایسه">
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z"/></svg>
          </button>
        </div>

        {/* Energy Rating */}
        {product.energyRating && product.energyRating !== "-" && (
          <div className="absolute top-3 left-3">
            <span className="px-2 py-1 bg-green-100 text-green-700 text-[10px] font-bold rounded-lg">
              {product.energyRating}
            </span>
          </div>
        )}
      </div>

      {/* Info */}
      <div className="p-4">
        <Link href={`/products/${product.slug}`} className="block">
          <p className="text-xs text-blue-600 font-medium mb-1.5">{product.category}</p>
          <h3 className="text-sm font-bold text-gray-800 mb-3 line-clamp-2 group-hover:text-blue-600 transition-colors leading-6">
            {product.name}
          </h3>
        </Link>

        {/* Rating */}
        <div className="flex items-center gap-2 mb-3">
          <div className="flex items-center gap-0.5">
            {[1, 2, 3, 4, 5].map((star) => (
              <svg key={star} className={`w-3.5 h-3.5 ${star <= Math.round(product.rating) ? 'text-yellow-400' : 'text-gray-200'}`} fill="currentColor" viewBox="0 0 20 20">
                <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"/>
              </svg>
            ))}
          </div>
          <span className="text-xs text-gray-400">({toFarsiNumber(product.reviewCount)} نظر)</span>
        </div>

        {/* Price */}
        <div className="flex items-end justify-between">
          <div>
            {product.discountPrice ? (
              <>
                <p className="text-xs text-gray-400 line-through mb-0.5">{formatPriceToman(product.price)}</p>
                <p className="text-base font-black text-blue-600">{formatPriceToman(product.discountPrice)}</p>
              </>
            ) : (
              <p className="text-base font-black text-gray-800">{formatPriceToman(product.price)}</p>
            )}
          </div>
          <Link href={`/products/${product.slug}`} className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold rounded-xl transition-colors shadow-sm">
            مشاهده
          </Link>
        </div>

        {/* Stock */}
        {product.stock <= 5 && product.stock > 0 && (
          <p className="mt-2 text-[10px] text-red-500 font-medium">تنها {toFarsiNumber(product.stock)} عدد باقی‌مانده</p>
        )}
      </div>
    </div>
  );
}
