import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { newsletters } from "@/db/schema";

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { email } = body;

    if (!email) {
      return NextResponse.json({ error: "ایمیل الزامی است" }, { status: 400 });
    }

    await db.insert(newsletters).values({ email }).onConflictDoNothing();

    return NextResponse.json({ success: true, message: "با موفقیت ثبت شد" });
  } catch (error) {
    console.error("Newsletter error:", error);
    return NextResponse.json({ error: "خطا در ثبت" }, { status: 500 });
  }
}
