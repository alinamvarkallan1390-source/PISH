import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { contactMessages } from "@/db/schema";

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { name, phone, email, subject, message } = body;

    if (!name || !phone || !message) {
      return NextResponse.json({ error: "اطلاعات ناقص است" }, { status: 400 });
    }

    await db.insert(contactMessages).values({
      name,
      phone,
      email: email || null,
      subject: subject || null,
      message,
    });

    return NextResponse.json({ success: true, message: "پیام با موفقیت ارسال شد" });
  } catch (error) {
    console.error("Contact error:", error);
    return NextResponse.json({ error: "خطا در ارسال پیام" }, { status: 500 });
  }
}
