import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { dealerRequests } from "@/db/schema";

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { companyName, contactName, phone, email, province, city, address, businessLicense, experience, storeInfo } = body;

    if (!companyName || !contactName || !phone) {
      return NextResponse.json({ error: "اطلاعات ناقص است" }, { status: 400 });
    }

    await db.insert(dealerRequests).values({
      companyName,
      contactName,
      phone,
      email: email || null,
      city: city || null,
      province: province || null,
      address: address || null,
      businessLicense: businessLicense || null,
      experience: experience || null,
      storeInfo: storeInfo || null,
    });

    return NextResponse.json({ success: true, message: "درخواست نمایندگی ثبت شد" });
  } catch (error) {
    console.error("Dealer error:", error);
    return NextResponse.json({ error: "خطا در ثبت درخواست" }, { status: 500 });
  }
}
