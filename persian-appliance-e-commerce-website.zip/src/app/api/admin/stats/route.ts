import { NextResponse } from "next/server";
import { db } from "@/db";
import { products, orders, contactMessages, dealerRequests, newsletters, reviews } from "@/db/schema";
import { sql } from "drizzle-orm";

export async function GET() {
  try {
    const [productCount] = await db.select({ count: sql<number>`count(*)` }).from(products);
    const [orderCount] = await db.select({ count: sql<number>`count(*)` }).from(orders);
    const [contactCount] = await db.select({ count: sql<number>`count(*)` }).from(contactMessages);
    const [dealerCount] = await db.select({ count: sql<number>`count(*)` }).from(dealerRequests);
    const [newsletterCount] = await db.select({ count: sql<number>`count(*)` }).from(newsletters);
    const [reviewCount] = await db.select({ count: sql<number>`count(*)` }).from(reviews);

    return NextResponse.json({
      products: Number(productCount.count),
      orders: Number(orderCount.count),
      contacts: Number(contactCount.count),
      dealers: Number(dealerCount.count),
      newsletters: Number(newsletterCount.count),
      reviews: Number(reviewCount.count),
    });
  } catch {
    return NextResponse.json({
      products: 0,
      orders: 0,
      contacts: 0,
      dealers: 0,
      newsletters: 0,
      reviews: 0,
    });
  }
}
