import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { cooperationRequests } from "@/db/schema";

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { type, fullName, phone, email, description } = body;

    if (!type || !fullName || !phone) {
      return NextResponse.json({ error: "اطلاعات ناقص است" }, { status: 400 });
    }

    await db.insert(cooperationRequests).values({
      type,
      fullName,
      phone,
      email: email || null,
      description: description || null,
    });

    return NextResponse.json({ success: true, message: "درخواست ثبت شد" });
  } catch (error) {
    console.error("Cooperation error:", error);
    return NextResponse.json({ error: "خطا در ثبت درخواست" }, { status: 500 });
  }
}
