"use client";

import Header from "@/components/Header";
import Footer from "@/components/Footer";
import AnimatedCounter from "@/components/AnimatedCounter";
import SectionTitle from "@/components/SectionTitle";
import { COMPANY, IMAGES } from "@/lib/constants";

export default function AboutPage() {
  return (
    <div className="min-h-screen">
      <Header />

      {/* Hero */}
      <section className="relative h-[400px] md:h-[500px] overflow-hidden">
        <img src={IMAGES.factory} alt="درباره پارس‌تک" className="w-full h-full object-cover" />
        <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/50 to-black/30" />
        <div className="absolute inset-0 flex items-center justify-center text-center">
          <div>
            <h1 className="text-4xl md:text-5xl font-black text-white mb-4">درباره پارس‌تک</h1>
            <p className="text-gray-300 text-lg max-w-xl mx-auto">بیش از سه دهه تعهد به کیفیت و نوآوری</p>
          </div>
        </div>
      </section>

      {/* History */}
      <section className="py-16 md:py-24">
        <div className="max-w-7xl mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <SectionTitle title="تاریخچه شرکت" subtitle="" centered={false} />
              <div className="space-y-4 text-gray-600 text-sm leading-8">
                <p>شرکت صنعتی پارس‌تک در سال {COMPANY.year} با هدف تولید لوازم خانگی با کیفیت و قیمت مناسب در شهرک صنعتی جی اصفهان تأسیس شد. این شرکت با سرمایه‌گذاری اولیه در خطوط تولید یخچال و فریزر، فعالیت خود را آغاز کرد.</p>
                <p>در طول سال‌ها، پارس‌تک با گسترش خطوط تولید و سرمایه‌گذاری در تحقیق و توسعه، محصولات متنوعی شامل ماشین لباسشویی، ظرفشویی، اجاق گاز، مایکروویو و سایر لوازم خانگی را به سبد محصولات خود اضافه کرده است.</p>
                <p>امروز پارس‌تک با بیش از {COMPANY.employees} کارمند متخصص و {COMPANY.dealers} نمایندگی فعال در سراسر ایران، یکی از بزرگ‌ترین و معتبرترین تولیدکنندگان لوازم خانگی کشور به شمار می‌رود.</p>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <img src={IMAGES.kitchen1} alt="کارخانه" className="rounded-2xl shadow-lg" />
              <img src={IMAGES.kitchen2} alt="تولید" className="rounded-2xl shadow-lg mt-8" />
              <img src={IMAGES.kitchen3} alt="آزمایشگاه" className="rounded-2xl shadow-lg" />
              <img src={IMAGES.kitchen4} alt="نمایشگاه" className="rounded-2xl shadow-lg mt-8" />
            </div>
          </div>
        </div>
      </section>

      {/* Mission & Vision */}
      <section className="py-16 md:py-24 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="bg-white rounded-2xl p-8 md:p-12 border border-gray-100 hover:shadow-xl transition-all">
              <div className="w-16 h-16 bg-blue-100 rounded-2xl flex items-center justify-center text-3xl mb-6">🎯</div>
              <h3 className="text-2xl font-black text-gray-900 mb-4">مأموریت ما</h3>
              <p className="text-gray-600 text-sm leading-8">
                مأموریت ما ارائه محصولات خانگی با کیفیت جهانی و قیمت مناسب به خانواده‌های ایرانی است. ما متعهد هستیم که با بهره‌گیری از جدیدترین فناوری‌ها و رعایت بالاترین استانداردهای کیفی، زندگی را برای مصرف‌کنندگان راحت‌تر و بهتر کنیم.
              </p>
            </div>
            <div className="bg-white rounded-2xl p-8 md:p-12 border border-gray-100 hover:shadow-xl transition-all">
              <div className="w-16 h-16 bg-blue-100 rounded-2xl flex items-center justify-center text-3xl mb-6">🔭</div>
              <h3 className="text-2xl font-black text-gray-900 mb-4">چشم‌انداز ما</h3>
              <p className="text-gray-600 text-sm leading-8">
                چشم‌انداز ما تبدیل شدن به برند شماره یک لوازم خانگی در خاورمیانه و ورود به بازارهای جهانی است. ما با تمرکز بر نوآوری، پایداری و رضایت مشتری، به سمت آینده‌ای روشن حرکت می‌کنیم.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Stats */}
      <section className="py-16 md:py-24 bg-gray-900">
        <div className="max-w-7xl mx-auto px-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {[
              { value: 2500, suffix: "+", label: "کارمند متخصص", icon: "👥" },
              { value: 350, suffix: "+", label: "محصول متنوع", icon: "📦" },
              { value: 1200, suffix: "+", label: "نمایندگی فعال", icon: "🏪" },
              { value: 28, suffix: "", label: "کشور صادراتی", icon: "🌍" },
            ].map((stat, idx) => (
              <div key={idx} className="text-center">
                <span className="text-4xl mb-4 block">{stat.icon}</span>
                <div className="text-4xl md:text-5xl font-black text-white mb-2">
                  <AnimatedCounter end={stat.value} suffix={stat.suffix} />
                </div>
                <p className="text-gray-400 text-sm">{stat.label}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Timeline */}
      <section className="py-16 md:py-24">
        <div className="max-w-3xl mx-auto px-4">
          <SectionTitle title="مراحل رشد و توسعه" subtitle="تاریخچه مختصر پارس‌تک از ابتدا تاکنون" />
          <div className="space-y-8">
            {[
              { year: "۱۳۶۵", title: "تأسیس شرکت", desc: "شروع فعالیت با تولید یخچال و فریزر خانگی" },
              { year: "۱۳۷۵", title: "گسترش خط تولید", desc: "اضافه شدن ماشین لباسشویی و اجاق گاز" },
              { year: "۱۳۸۵", title: "صادرات", desc: "آغاز صادرات به کشورهای همسایه و خاورمیانه" },
              { year: "۱۳۹۰", title: "کسب استانداردهای جهانی", desc: "دریافت گواهینامه‌های ISO و CE" },
              { year: "۱۳۹۸", title: "محصولات هوشمند", desc: "معرفی اولین سری محصولات هوشمند با اتصال WiFi" },
              { year: "۱۴۰۴", title: "رهبری بازار", desc: "حضور در بیش از ۲۸ کشور و ۱۲۰۰ نمایندگی فعال" },
            ].map((item, idx) => (
              <div key={idx} className="flex gap-6 items-start">
                <div className="flex flex-col items-center">
                  <div className="w-12 h-12 bg-blue-600 text-white rounded-full flex items-center justify-center font-bold text-xs flex-shrink-0">{item.year}</div>
                  {idx < 5 && <div className="w-0.5 h-full bg-blue-200 mt-2" />}
                </div>
                <div className="pb-8">
                  <h4 className="text-base font-bold text-gray-900 mb-1">{item.title}</h4>
                  <p className="text-sm text-gray-500">{item.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Gallery */}
      <section className="py-16 md:py-24 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4">
          <SectionTitle title="گالری تصاویر" subtitle="تصاویری از کارخانه، خطوط تولید و نمایشگاه‌های پارس‌تک" />
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
            {[IMAGES.hero1, IMAGES.hero2, IMAGES.hero3, IMAGES.kitchen1, IMAGES.kitchen2, IMAGES.kitchen3, IMAGES.kitchen4, IMAGES.kitchen5].map((img, idx) => (
              <div key={idx} className="aspect-square rounded-2xl overflow-hidden group cursor-pointer">
                <img src={img} alt={`گالری ${idx + 1}`} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" loading="lazy" />
              </div>
            ))}
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
