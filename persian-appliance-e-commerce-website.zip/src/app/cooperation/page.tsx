"use client";

import { useState } from "react";
import Header from "@/components/Header";
import Footer from "@/components/Footer";

export default function CooperationPage() {
  const [activeTab, setActiveTab] = useState<"employment" | "supplier" | "business">("employment");
  const [form, setForm] = useState({ type: "employment", fullName: "", phone: "", email: "", description: "" });
  const [submitted, setSubmitted] = useState(false);
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      await fetch("/api/cooperation", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ ...form, type: activeTab }) });
      setSubmitted(true);
    } catch { /* ignore */ }
    setLoading(false);
  };

  const tabs = [
    { key: "employment" as const, label: "استخدام", icon: "💼", desc: "به تیم حرفه‌ای پارس‌تک بپیوندید" },
    { key: "supplier" as const, label: "تأمین‌کنندگان", icon: "🏭", desc: "ثبت‌نام تأمین‌کنندگان مواد اولیه" },
    { key: "business" as const, label: "همکاری تجاری", icon: "🤝", desc: "پیشنهاد همکاری تجاری" },
  ];

  const positions = [
    { title: "مهندس کنترل کیفیت", dept: "واحد کیفیت", location: "اصفهان (کارخانه)", type: "تمام وقت" },
    { title: "کارشناس فروش منطقه‌ای", dept: "واحد فروش", location: "تهران", type: "تمام وقت" },
    { title: "طراح صنعتی", dept: "واحد تحقیق و توسعه", location: "اصفهان", type: "تمام وقت" },
    { title: "برنامه‌نویس وب", dept: "واحد فناوری اطلاعات", location: "تهران", type: "تمام وقت / دورکاری" },
    { title: "کارشناس بازاریابی دیجیتال", dept: "واحد بازاریابی", location: "تهران", type: "تمام وقت" },
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      <section className="bg-gradient-to-l from-blue-800 to-blue-900 py-16 md:py-24">
        <div className="max-w-7xl mx-auto px-4 text-center">
          <h1 className="text-4xl md:text-5xl font-black text-white mb-4">همکاری با پارس‌تک</h1>
          <p className="text-blue-200 max-w-lg mx-auto">در هر زمینه‌ای آماده همکاری با شما هستیم</p>
        </div>
      </section>

      <section className="max-w-5xl mx-auto px-4 py-16">
        {/* Tabs */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-10">
          {tabs.map((tab) => (
            <button
              key={tab.key}
              onClick={() => { setActiveTab(tab.key); setSubmitted(false); }}
              className={`p-6 rounded-2xl border-2 text-center transition-all ${
                activeTab === tab.key
                  ? "border-blue-600 bg-blue-50 shadow-lg"
                  : "border-gray-200 bg-white hover:border-gray-300"
              }`}
            >
              <span className="text-3xl mb-3 block">{tab.icon}</span>
              <h3 className="text-base font-bold text-gray-900 mb-1">{tab.label}</h3>
              <p className="text-xs text-gray-500">{tab.desc}</p>
            </button>
          ))}
        </div>

        {/* Employment - Job Positions */}
        {activeTab === "employment" && (
          <div className="mb-10">
            <h2 className="text-xl font-black text-gray-900 mb-6">موقعیت‌های شغلی فعال</h2>
            <div className="space-y-3">
              {positions.map((pos, idx) => (
                <div key={idx} className="bg-white rounded-2xl p-6 border border-gray-100 flex flex-col md:flex-row md:items-center justify-between gap-4 hover:shadow-lg transition-all">
                  <div>
                    <h3 className="text-base font-bold text-gray-900 mb-1">{pos.title}</h3>
                    <div className="flex items-center gap-3 text-xs text-gray-500">
                      <span>{pos.dept}</span>
                      <span>•</span>
                      <span>{pos.location}</span>
                      <span>•</span>
                      <span>{pos.type}</span>
                    </div>
                  </div>
                  <button className="px-5 py-2.5 bg-blue-600 text-white text-sm font-bold rounded-xl hover:bg-blue-700 transition-colors whitespace-nowrap">
                    ارسال رزومه
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Form */}
        <div className="bg-white rounded-2xl p-8 md:p-10 border border-gray-100 shadow-sm">
          <h2 className="text-xl font-black text-gray-900 mb-6">
            {activeTab === "employment" ? "ارسال رزومه" : activeTab === "supplier" ? "ثبت‌نام تأمین‌کننده" : "درخواست همکاری"}
          </h2>
          {submitted ? (
            <div className="text-center py-12">
              <span className="text-5xl mb-4 block">✅</span>
              <h3 className="text-xl font-bold text-green-600 mb-2">اطلاعات شما با موفقیت ثبت شد</h3>
              <p className="text-sm text-gray-500">تیم ما در اسرع وقت درخواست شما را بررسی خواهد کرد</p>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-5">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">نام و نام خانوادگی *</label>
                  <input type="text" required value={form.fullName} onChange={(e) => setForm({ ...form, fullName: e.target.value })} className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">شماره تماس *</label>
                  <input type="tel" required value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500" dir="ltr" />
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">ایمیل</label>
                <input type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500" dir="ltr" />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">توضیحات *</label>
                <textarea required rows={5} value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 resize-none" placeholder={activeTab === "employment" ? "سوابق و مهارت‌های خود را شرح دهید..." : "توضیحات خود را بنویسید..."} />
              </div>
              <button type="submit" disabled={loading} className="w-full py-3.5 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-xl transition-colors shadow-lg disabled:opacity-50">
                {loading ? "در حال ارسال..." : "ارسال درخواست"}
              </button>
            </form>
          )}
        </div>
      </section>

      <Footer />
    </div>
  );
}
