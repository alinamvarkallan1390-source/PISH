"use client";

import { useState, useEffect } from "react";
import Link from "next/link";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import ProductCard from "@/components/ProductCard";
import AnimatedCounter from "@/components/AnimatedCounter";
import SectionTitle from "@/components/SectionTitle";
import { COMPANY, IMAGES, CATEGORIES, SAMPLE_PRODUCTS, BLOG_POSTS, TESTIMONIALS } from "@/lib/constants";
import { formatPriceToman, toFarsiNumber } from "@/lib/utils";

const SLIDES = [
  {
    image: IMAGES.hero1,
    title: "فناوری برتر، زندگی بهتر",
    subtitle: "جدیدترین یخچال فریزرهای ساید بای ساید با فناوری نوفراست و کمپرسور اینورتر",
    cta: "مشاهده محصولات",
    link: "/products?category=refrigerators",
  },
  {
    image: IMAGES.hero2,
    title: "لباسشویی‌های هوشمند",
    subtitle: "ماشین لباسشویی با موتور اینورتر، ۱۶ برنامه شست‌وشو و مصرف انرژی بهینه",
    cta: "بیشتر بدانید",
    link: "/products?category=washing-machines",
  },
  {
    image: IMAGES.hero3,
    title: "آشپزخانه رؤیایی",
    subtitle: "مجموعه کامل لوازم آشپزخانه با طراحی مدرن و استانداردهای جهانی",
    cta: "فروش ویژه",
    link: "/products",
  },
];

export default function HomePage() {
  const [currentSlide, setCurrentSlide] = useState(0);
  const [activeTestimonial, setActiveTestimonial] = useState(0);
  const [faqOpen, setFaqOpen] = useState<number | null>(null);

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % SLIDES.length);
    }, 5000);
    return () => clearInterval(timer);
  }, []);

  useEffect(() => {
    const timer = setInterval(() => {
      setActiveTestimonial((prev) => (prev + 1) % TESTIMONIALS.length);
    }, 4000);
    return () => clearInterval(timer);
  }, []);

  const featuredProducts = SAMPLE_PRODUCTS.filter((p) => p.isFeatured);
  const bestSellers = SAMPLE_PRODUCTS.filter((p) => p.isBestSeller);
  const newProducts = SAMPLE_PRODUCTS.filter((p) => p.isNew);
  const discountedProducts = SAMPLE_PRODUCTS.filter((p) => p.discount > 0);

  const faqs = [
    { q: "آیا محصولات پارس‌تک گارانتی دارند؟", a: "بله، تمامی محصولات پارس‌تک دارای گارانتی اصل و خدمات پس از فروش هستند. مدت گارانتی بسته به نوع محصول از ۲ تا ۱۰ سال متغیر است." },
    { q: "نحوه ارسال سفارش چگونه است؟", a: "سفارشات در سراسر کشور با پست پیشتاز یا تیپاکس ارسال می‌شوند. برای کالاهای بزرگ، ارسال رایگان انجام می‌شود." },
    { q: "امکان خرید اقساطی وجود دارد؟", a: "بله، با همکاری بانک‌های عامل، امکان خرید اقساطی با چک و کارت اعتباری فراهم است." },
    { q: "نصب محصول چگونه انجام می‌شود؟", a: "برای محصولات بزرگ مانند یخچال و لباسشویی، نصب رایگان توسط تکنسین‌های مجاز پارس‌تک انجام می‌شود." },
    { q: "آیا امکان مرجوع کردن محصول وجود دارد؟", a: "بله، تا ۷ روز پس از دریافت محصول، امکان مرجوعی بدون قید و شرط وجود دارد." },
  ];

  return (
    <div className="min-h-screen">
      <Header />

      {/* Hero Slider */}
      <section className="relative h-[500px] md:h-[600px] lg:h-[700px] overflow-hidden">
        {SLIDES.map((slide, index) => (
          <div
            key={index}
            className={`absolute inset-0 transition-all duration-1000 ${
              index === currentSlide ? "opacity-100 scale-100" : "opacity-0 scale-105"
            }`}
          >
            <img src={slide.image} alt={slide.title} className="w-full h-full object-cover" />
            <div className="absolute inset-0 bg-gradient-to-l from-black/70 via-black/50 to-transparent" />
            <div className="absolute inset-0 flex items-center">
              <div className="max-w-7xl mx-auto px-4 w-full">
                <div className="max-w-xl animate-fade-in-up">
                  <span className="inline-block px-4 py-1.5 bg-blue-600/90 text-white text-xs font-bold rounded-full mb-4">
                    {COMPANY.name} — {COMPANY.slogan}
                  </span>
                  <h2 className="text-3xl md:text-5xl lg:text-6xl font-black text-white mb-4 leading-tight">
                    {slide.title}
                  </h2>
                  <p className="text-gray-200 text-sm md:text-base mb-8 leading-7">
                    {slide.subtitle}
                  </p>
                  <Link
                    href={slide.link}
                    className="inline-flex items-center gap-2 px-8 py-4 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-xl transition-all shadow-lg hover:shadow-xl hover:shadow-blue-500/20"
                  >
                    {slide.cta}
                    <svg className="w-4 h-4 rotate-180" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14 5l7 7m0 0l-7 7m7-7H3"/></svg>
                  </Link>
                </div>
              </div>
            </div>
          </div>
        ))}

        {/* Slider dots */}
        <div className="absolute bottom-8 left-1/2 -translate-x-1/2 flex gap-2">
          {SLIDES.map((_, idx) => (
            <button
              key={idx}
              onClick={() => setCurrentSlide(idx)}
              className={`h-2 rounded-full transition-all duration-300 ${
                idx === currentSlide ? "w-8 bg-blue-500" : "w-2 bg-white/50 hover:bg-white/70"
              }`}
            />
          ))}
        </div>
      </section>

      {/* Features Bar */}
      <section className="bg-white border-b border-gray-100">
        <div className="max-w-7xl mx-auto px-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-0 divide-x divide-x-reverse divide-gray-100">
            {[
              { icon: "🚚", title: "ارسال رایگان", desc: "برای سفارش‌های بالای ۵ میلیون" },
              { icon: "🔒", title: "پرداخت امن", desc: "درگاه بانکی معتبر" },
              { icon: "🏆", title: "ضمانت اصالت", desc: "تمامی محصولات اصل هستند" },
              { icon: "📞", title: "پشتیبانی ۲۴/۷", desc: "پاسخ‌گویی شبانه‌روزی" },
            ].map((feature, idx) => (
              <div key={idx} className="p-6 md:p-8 text-center group hover:bg-blue-50/50 transition-colors">
                <span className="text-3xl md:text-4xl mb-3 block group-hover:animate-float">{feature.icon}</span>
                <h3 className="text-sm font-bold text-gray-800 mb-1">{feature.title}</h3>
                <p className="text-xs text-gray-500">{feature.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Categories */}
      <section className="py-16 md:py-24 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4">
          <SectionTitle title="دسته‌بندی محصولات" subtitle="تمامی لوازم خانگی مورد نیاز شما در یک مکان" />
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
            {CATEGORIES.slice(0, 12).map((cat) => (
              <Link
                key={cat.id}
                href={`/products?category=${cat.slug}`}
                className="group bg-white rounded-2xl p-5 text-center hover:shadow-xl hover:shadow-blue-500/10 hover:border-blue-200 border border-gray-100 transition-all duration-300 hover:-translate-y-1"
              >
                <span className="text-4xl mb-3 block group-hover:scale-110 transition-transform">{cat.icon}</span>
                <h3 className="text-sm font-bold text-gray-800 group-hover:text-blue-600 transition-colors">{cat.name}</h3>
                <p className="text-xs text-gray-400 mt-1">{toFarsiNumber(cat.count)} محصول</p>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Featured Products */}
      <section className="py-16 md:py-24">
        <div className="max-w-7xl mx-auto px-4">
          <SectionTitle title="محصولات ویژه" subtitle="برترین محصولات پارس‌تک با بهترین کیفیت و قیمت" />
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {featuredProducts.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
          <div className="text-center mt-10">
            <Link href="/products" className="inline-flex items-center gap-2 px-8 py-3.5 border-2 border-blue-600 text-blue-600 hover:bg-blue-600 hover:text-white font-bold text-sm rounded-xl transition-all">
              مشاهده همه محصولات
              <svg className="w-4 h-4 rotate-180" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14 5l7 7m0 0l-7 7m7-7H3"/></svg>
            </Link>
          </div>
        </div>
      </section>

      {/* Special Offers Banner */}
      <section className="py-16 md:py-24 bg-gradient-to-l from-blue-900 via-blue-800 to-blue-700 relative overflow-hidden">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-0 right-0 w-96 h-96 bg-white rounded-full -translate-y-1/2 translate-x-1/2" />
          <div className="absolute bottom-0 left-0 w-64 h-64 bg-white rounded-full translate-y-1/2 -translate-x-1/2" />
        </div>
        <div className="max-w-7xl mx-auto px-4 relative">
          <SectionTitle title="پیشنهادهای شگفت‌انگیز" subtitle="تخفیف‌های ویژه با زمان محدود — فرصت را از دست ندهید" light />
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {discountedProducts.map((product) => (
              <div key={product.id} className="bg-white/10 backdrop-blur-sm border border-white/20 rounded-2xl overflow-hidden group hover:bg-white/20 transition-all">
                <div className="relative aspect-[4/3] overflow-hidden">
                  <img src={product.image} alt={product.name} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" loading="lazy" />
                  <div className="absolute top-3 right-3 px-3 py-1.5 bg-red-500 text-white text-xs font-black rounded-lg">
                    {toFarsiNumber(product.discount)}% تخفیف
                  </div>
                </div>
                <div className="p-4">
                  <h3 className="text-white font-bold text-sm mb-2 line-clamp-2">{product.name}</h3>
                  <div className="flex items-center gap-2">
                    <span className="text-white/50 text-xs line-through">{formatPriceToman(product.price)}</span>
                  </div>
                  <div className="flex items-center justify-between mt-2">
                    <span className="text-yellow-300 font-black text-base">{formatPriceToman(product.discountPrice!)}</span>
                    <Link href={`/products/${product.slug}`} className="px-4 py-2 bg-white text-blue-700 text-xs font-bold rounded-xl hover:bg-blue-50 transition-colors">
                      خرید
                    </Link>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Best Sellers */}
      <section className="py-16 md:py-24">
        <div className="max-w-7xl mx-auto px-4">
          <SectionTitle title="پرفروش‌ترین محصولات" subtitle="محبوب‌ترین محصولات از نگاه مشتریان" />
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {bestSellers.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        </div>
      </section>

      {/* Company About */}
      <section className="py-16 md:py-24 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <span className="text-blue-600 font-bold text-sm mb-3 block">درباره پارس‌تک</span>
              <h2 className="text-3xl md:text-4xl font-black text-gray-900 mb-6 leading-tight">
                بیش از سه دهه <span className="gradient-text">تجربه و نوآوری</span> در صنعت لوازم خانگی
              </h2>
              <p className="text-gray-600 leading-8 mb-6">
                شرکت صنعتی پارس‌تک با بیش از ۳۵ سال سابقه درخشان در صنعت لوازم خانگی ایران، با بهره‌گیری از جدیدترین فناوری‌های روز دنیا و کادر متخصص، محصولاتی با کیفیت جهانی تولید و عرضه می‌کند. ما با داشتن خطوط تولید پیشرفته و آزمایشگاه‌های مجهز، همواره در تلاش هستیم تا بهترین‌ها را به خانواده‌های ایرانی ارائه دهیم.
              </p>
              <div className="grid grid-cols-2 gap-4 mb-8">
                {[
                  { label: "تحقیق و توسعه", desc: "آزمایشگاه‌های مجهز" },
                  { label: "استانداردهای بین‌المللی", desc: "ISO 9001, CE, ISIRI" },
                  { label: "خدمات پس از فروش", desc: "در سراسر ایران" },
                  { label: "صادرات", desc: "به ۲۸ کشور جهان" },
                ].map((item, idx) => (
                  <div key={idx} className="flex items-start gap-3">
                    <div className="w-6 h-6 bg-blue-100 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                      <svg className="w-3.5 h-3.5 text-blue-600" fill="currentColor" viewBox="0 0 20 20"><path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd"/></svg>
                    </div>
                    <div>
                      <span className="text-sm font-bold text-gray-800 block">{item.label}</span>
                      <span className="text-xs text-gray-500">{item.desc}</span>
                    </div>
                  </div>
                ))}
              </div>
              <Link href="/about" className="inline-flex items-center gap-2 px-6 py-3 bg-blue-600 hover:bg-blue-700 text-white font-bold text-sm rounded-xl transition-colors shadow-lg">
                بیشتر بخوانید
                <svg className="w-4 h-4 rotate-180" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14 5l7 7m0 0l-7 7m7-7H3"/></svg>
              </Link>
            </div>
            <div className="relative">
              <img src={IMAGES.factory} alt="کارخانه پارس‌تک" className="rounded-2xl shadow-2xl w-full" />
              <div className="absolute -bottom-6 -right-6 bg-white rounded-2xl shadow-xl p-6 hidden md:block">
                <div className="text-center">
                  <span className="text-4xl font-black text-blue-600 block">
                    <AnimatedCounter end={35} suffix="+" />
                  </span>
                  <span className="text-sm text-gray-600 font-medium">سال تجربه</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Statistics */}
      <section className="py-16 md:py-24 bg-gray-900 relative overflow-hidden">
        <div className="absolute inset-0 opacity-5">
          <div className="absolute top-1/4 right-1/4 w-96 h-96 bg-blue-500 rounded-full blur-3xl" />
          <div className="absolute bottom-1/4 left-1/4 w-96 h-96 bg-blue-500 rounded-full blur-3xl" />
        </div>
        <div className="max-w-7xl mx-auto px-4 relative">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {[
              { value: 2500, suffix: "+", label: "کارمند متخصص", icon: "👥" },
              { value: 350, suffix: "+", label: "محصول متنوع", icon: "📦" },
              { value: 1200, suffix: "+", label: "نمایندگی فعال", icon: "🏪" },
              { value: 28, suffix: "", label: "کشور صادراتی", icon: "🌍" },
            ].map((stat, idx) => (
              <div key={idx} className="text-center group">
                <span className="text-4xl mb-4 block group-hover:scale-110 transition-transform">{stat.icon}</span>
                <div className="text-4xl md:text-5xl font-black text-white mb-2">
                  <AnimatedCounter end={stat.value} suffix={stat.suffix} />
                </div>
                <p className="text-gray-400 text-sm font-medium">{stat.label}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* New Products */}
      <section className="py-16 md:py-24">
        <div className="max-w-7xl mx-auto px-4">
          <SectionTitle title="جدیدترین محصولات" subtitle="آخرین محصولات اضافه شده به فروشگاه پارس‌تک" />
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {newProducts.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        </div>
      </section>

      {/* Technologies */}
      <section className="py-16 md:py-24 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4">
          <SectionTitle title="فناوری‌های پیشرفته" subtitle="جدیدترین فناوری‌های بکار رفته در محصولات پارس‌تک" />
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[
              { icon: "⚡", title: "کمپرسور اینورتر", desc: "کاهش ۴۰٪ مصرف انرژی و عملکرد بی‌صدا با تنظیم هوشمند دور موتور" },
              { icon: "❄️", title: "نوفراست پیشرفته", desc: "سیستم ضد برفک هوشمند برای عملکرد بهینه و بدون نیاز به یخ‌زدایی دستی" },
              { icon: "📱", title: "اتصال هوشمند WiFi", desc: "کنترل و مانیتورینگ از راه دور با اپلیکیشن اختصاصی پارس‌تک" },
              { icon: "🌿", title: "سازگار با محیط زیست", desc: "استفاده از گازهای خنک‌کننده سازگار با محیط زیست و مصرف انرژی بهینه" },
              { icon: "🔇", title: "فناوری بی‌صدا", desc: "سطح صدای زیر ۳۸ دسی‌بل برای آرامش کامل در خانه" },
              { icon: "🛡️", title: "محافظت هوشمند", desc: "سیستم‌های ایمنی پیشرفته شامل قفل کودک و محافظ ولتاژ" },
            ].map((tech, idx) => (
              <div key={idx} className="bg-white rounded-2xl p-8 border border-gray-100 hover:border-blue-200 hover:shadow-xl hover:shadow-blue-500/5 transition-all duration-300 group">
                <span className="text-4xl mb-4 block group-hover:scale-110 transition-transform">{tech.icon}</span>
                <h3 className="text-lg font-bold text-gray-900 mb-3">{tech.title}</h3>
                <p className="text-sm text-gray-500 leading-7">{tech.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Why Choose Us */}
      <section className="py-16 md:py-24">
        <div className="max-w-7xl mx-auto px-4">
          <SectionTitle title="چرا پارس‌تک؟" subtitle="دلایلی که ما را از رقبا متمایز می‌کند" />
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {[
              { icon: "🏭", title: "تولید داخلی", desc: "کارخانه مجهز در اصفهان با خطوط تولید اتوماتیک و استانداردهای جهانی", color: "blue" },
              { icon: "🛡️", title: "گارانتی معتبر", desc: "تا ۱۰ سال گارانتی تعویض و خدمات پس از فروش در سراسر ایران", color: "green" },
              { icon: "💎", title: "کیفیت برتر", desc: "محصولات با بالاترین استانداردهای کیفی و آزمایش‌های سختگیرانه", color: "purple" },
              { icon: "🤝", title: "رضایت مشتری", desc: "بیش از ۹۸٪ رضایتمندی مشتریان ما از محصولات و خدمات", color: "orange" },
            ].map((item, idx) => (
              <div key={idx} className="text-center p-8 rounded-2xl border border-gray-100 hover:border-blue-200 hover:shadow-xl transition-all duration-300 bg-white group">
                <span className="text-5xl mb-5 block group-hover:animate-float">{item.icon}</span>
                <h3 className="text-lg font-bold text-gray-900 mb-3">{item.title}</h3>
                <p className="text-sm text-gray-500 leading-7">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-16 md:py-24 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4">
          <SectionTitle title="نظرات مشتریان" subtitle="آنچه مشتریان ما درباره محصولات پارس‌تک می‌گویند" />
          <div className="max-w-3xl mx-auto">
            <div className="bg-white rounded-2xl p-8 md:p-12 shadow-sm border border-gray-100 relative">
              <div className="absolute top-6 right-8 text-6xl text-blue-100 font-serif leading-none">&ldquo;</div>
              <div className="relative">
                {TESTIMONIALS.map((testimonial, idx) => (
                  <div
                    key={idx}
                    className={`transition-all duration-500 ${
                      idx === activeTestimonial ? "opacity-100 block" : "opacity-0 hidden"
                    }`}
                  >
                    <p className="text-gray-600 text-base leading-8 mb-6">{testimonial.text}</p>
                    <div className="flex items-center gap-2 mb-3">
                      {[1, 2, 3, 4, 5].map((star) => (
                        <svg key={star} className={`w-4 h-4 ${star <= testimonial.rating ? 'text-yellow-400' : 'text-gray-200'}`} fill="currentColor" viewBox="0 0 20 20">
                          <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"/>
                        </svg>
                      ))}
                    </div>
                    <div className="flex items-center gap-3">
                      <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-blue-700 rounded-full flex items-center justify-center text-white font-bold">
                        {testimonial.name.charAt(0)}
                      </div>
                      <div>
                        <h4 className="font-bold text-gray-900">{testimonial.name}</h4>
                        <p className="text-xs text-gray-500">{testimonial.city} — {testimonial.product}</p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
            <div className="flex justify-center gap-2 mt-6">
              {TESTIMONIALS.map((_, idx) => (
                <button
                  key={idx}
                  onClick={() => setActiveTestimonial(idx)}
                  className={`h-2 rounded-full transition-all ${
                    idx === activeTestimonial ? "w-8 bg-blue-500" : "w-2 bg-gray-300"
                  }`}
                />
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Certificates & Partners */}
      <section className="py-16 md:py-24">
        <div className="max-w-7xl mx-auto px-4">
          <SectionTitle title="گواهینامه‌ها و افتخارات" subtitle="استانداردها و گواهینامه‌های کسب شده توسط پارس‌تک" />
          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-6">
            {[
              { name: "ISO 9001:2015", icon: "🏅" },
              { name: "ISO 14001", icon: "🌿" },
              { name: "استاندارد ملی", icon: "✅" },
              { name: "CE اروپا", icon: "🇪🇺" },
              { name: "نشان کیفیت", icon: "⭐" },
              { name: "صنعت سبز", icon: "♻️" },
            ].map((cert, idx) => (
              <div key={idx} className="bg-gray-50 rounded-2xl p-6 text-center border border-gray-100 hover:border-blue-200 hover:bg-blue-50/50 transition-all group">
                <span className="text-4xl block mb-3 group-hover:scale-110 transition-transform">{cert.icon}</span>
                <h4 className="text-sm font-bold text-gray-700">{cert.name}</h4>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Blog */}
      <section className="py-16 md:py-24 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4">
          <SectionTitle title="آخرین مقالات بلاگ" subtitle="مقالات آموزشی، راهنمای خرید و اخبار صنعت لوازم خانگی" />
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {BLOG_POSTS.map((post) => (
              <Link key={post.id} href={`/blog/${post.slug}`} className="group bg-white rounded-2xl overflow-hidden border border-gray-100 hover:shadow-xl hover:border-blue-100 transition-all duration-300">
                <div className="aspect-[16/10] overflow-hidden">
                  <img src={post.image} alt={post.title} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" loading="lazy" />
                </div>
                <div className="p-5">
                  <span className="text-xs text-blue-600 font-medium">{post.category}</span>
                  <h3 className="text-sm font-bold text-gray-800 mt-2 mb-3 line-clamp-2 group-hover:text-blue-600 transition-colors leading-6">
                    {post.title}
                  </h3>
                  <p className="text-xs text-gray-500 line-clamp-2 leading-5 mb-3">{post.excerpt}</p>
                  <div className="flex items-center justify-between text-xs text-gray-400">
                    <span>{post.date}</span>
                    <span>{post.readTime} مطالعه</span>
                  </div>
                </div>
              </Link>
            ))}
          </div>
          <div className="text-center mt-10">
            <Link href="/blog" className="inline-flex items-center gap-2 px-8 py-3.5 border-2 border-gray-300 text-gray-700 hover:border-blue-600 hover:text-blue-600 font-bold text-sm rounded-xl transition-all">
              مشاهده همه مقالات
            </Link>
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section className="py-16 md:py-24">
        <div className="max-w-3xl mx-auto px-4">
          <SectionTitle title="سؤالات متداول" subtitle="پاسخ سؤالات رایج مشتریان" />
          <div className="space-y-3">
            {faqs.map((faq, idx) => (
              <div key={idx} className="bg-white rounded-2xl border border-gray-100 overflow-hidden transition-all">
                <button
                  onClick={() => setFaqOpen(faqOpen === idx ? null : idx)}
                  className="w-full px-6 py-5 flex items-center justify-between text-right hover:bg-gray-50 transition-colors"
                >
                  <span className="text-sm font-bold text-gray-800">{faq.q}</span>
                  <svg className={`w-5 h-5 text-gray-400 flex-shrink-0 transition-transform ${faqOpen === idx ? 'rotate-180' : ''}`} fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7"/></svg>
                </button>
                <div className={`overflow-hidden transition-all duration-300 ${faqOpen === idx ? 'max-h-40 pb-5' : 'max-h-0'}`}>
                  <p className="px-6 text-sm text-gray-600 leading-7">{faq.a}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Contact CTA */}
      <section className="py-16 md:py-24 bg-gradient-to-l from-gray-900 to-gray-800">
        <div className="max-w-7xl mx-auto px-4 text-center">
          <h2 className="text-3xl md:text-4xl font-black text-white mb-4">سؤالی دارید؟ با ما تماس بگیرید</h2>
          <p className="text-gray-400 text-sm mb-8 max-w-lg mx-auto">تیم پشتیبانی پارس‌تک آماده پاسخ‌گویی به سؤالات شما است</p>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <Link href="/contact" className="px-8 py-4 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-xl transition-colors shadow-lg">
              تماس با ما
            </Link>
            <a href={`tel:${COMPANY.phone}`} className="px-8 py-4 bg-white/10 hover:bg-white/20 text-white font-bold rounded-xl transition-colors border border-white/20">
              📞 {COMPANY.phone}
            </a>
          </div>
        </div>
      </section>

      {/* Map section */}
      <section className="h-[300px] md:h-[400px] bg-gray-200 relative">
        <iframe
          src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3239.895!2d51.4!3d35.75!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zMzXCsDQ1JzAwLjAiTiA1McKwMjQnMDAuMCJF!5e0!3m2!1sfa!2sir!4v1"
          className="w-full h-full border-0"
          allowFullScreen
          loading="lazy"
          referrerPolicy="no-referrer-when-downgrade"
          title="نقشه پارس‌تک"
        />
        <div className="absolute bottom-6 right-6 bg-white rounded-2xl p-5 shadow-xl max-w-sm hidden md:block">
          <h4 className="font-bold text-gray-900 text-sm mb-2">دفتر مرکزی پارس‌تک</h4>
          <p className="text-xs text-gray-500 leading-6">{COMPANY.address}</p>
        </div>
      </section>

      <Footer />
    </div>
  );
}
