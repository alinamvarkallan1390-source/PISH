import Link from "next/link";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { CATEGORIES } from "@/lib/constants";

export default function SitemapPage() {
  const sections = [
    {
      title: "صفحات اصلی",
      links: [
        { href: "/", label: "صفحه اصلی" },
        { href: "/products", label: "محصولات" },
        { href: "/about", label: "درباره ما" },
        { href: "/blog", label: "بلاگ" },
        { href: "/contact", label: "تماس با ما" },
      ],
    },
    {
      title: "دسته‌بندی محصولات",
      links: CATEGORIES.map((c) => ({ href: `/products?category=${c.slug}`, label: c.name })),
    },
    {
      title: "خدمات مشتریان",
      links: [
        { href: "/cart", label: "سبد خرید" },
        { href: "/checkout", label: "تسویه حساب" },
        { href: "/tracking", label: "پیگیری سفارش" },
        { href: "/warranty", label: "ثبت گارانتی" },
        { href: "/dashboard", label: "حساب کاربری" },
      ],
    },
    {
      title: "همکاری",
      links: [
        { href: "/dealer", label: "درخواست نمایندگی" },
        { href: "/cooperation", label: "همکاری با ما" },
      ],
    },
    {
      title: "قوانین",
      links: [
        { href: "/privacy", label: "حریم خصوصی" },
        { href: "/terms", label: "شرایط استفاده" },
      ],
    },
  ];

  return (
    <div className="min-h-screen">
      <Header />
      <div className="max-w-5xl mx-auto px-4 py-16">
        <h1 className="text-3xl font-black text-gray-900 mb-10">نقشه سایت</h1>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {sections.map((section, idx) => (
            <div key={idx} className="bg-white rounded-2xl p-6 border border-gray-100">
              <h2 className="text-base font-bold text-gray-900 mb-4 pb-3 border-b border-gray-100">{section.title}</h2>
              <ul className="space-y-2">
                {section.links.map((link, i) => (
                  <li key={i}>
                    <Link href={link.href} className="text-sm text-blue-600 hover:text-blue-700 hover:underline transition-colors">
                      {link.label}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </div>
      <Footer />
    </div>
  );
}
