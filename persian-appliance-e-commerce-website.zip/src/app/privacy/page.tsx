import Header from "@/components/Header";
import Footer from "@/components/Footer";

export default function PrivacyPage() {
  return (
    <div className="min-h-screen">
      <Header />
      <div className="max-w-3xl mx-auto px-4 py-16">
        <h1 className="text-3xl font-black text-gray-900 mb-8">سیاست حفظ حریم خصوصی</h1>
        <div className="bg-white rounded-2xl p-8 border border-gray-100 space-y-6 text-sm text-gray-600 leading-8">
          <section>
            <h2 className="text-lg font-bold text-gray-900 mb-3">۱. جمع‌آوری اطلاعات</h2>
            <p>شرکت پارس‌تک متعهد به حفظ حریم خصوصی کاربران است. اطلاعات شخصی شما صرفاً برای ارائه خدمات بهتر جمع‌آوری می‌شود و هیچ‌گاه در اختیار اشخاص ثالث قرار نمی‌گیرد.</p>
          </section>
          <section>
            <h2 className="text-lg font-bold text-gray-900 mb-3">۲. استفاده از اطلاعات</h2>
            <p>اطلاعات جمع‌آوری شده برای پردازش سفارشات، ارسال اطلاعیه‌های مهم، بهبود خدمات و ارائه پیشنهادات ویژه استفاده می‌شود.</p>
          </section>
          <section>
            <h2 className="text-lg font-bold text-gray-900 mb-3">۳. امنیت اطلاعات</h2>
            <p>تمامی اطلاعات کاربران با استفاده از پروتکل‌های امنیتی SSL و رمزنگاری پیشرفته محافظت می‌شوند.</p>
          </section>
          <section>
            <h2 className="text-lg font-bold text-gray-900 mb-3">۴. حقوق کاربران</h2>
            <p>هر کاربر حق دسترسی، اصلاح و حذف اطلاعات شخصی خود را دارد. برای اعمال این حقوق با بخش پشتیبانی تماس بگیرید.</p>
          </section>
        </div>
      </div>
      <Footer />
    </div>
  );
}
