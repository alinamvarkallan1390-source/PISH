"use client";

import { useState } from "react";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import SectionTitle from "@/components/SectionTitle";
import { COMPANY } from "@/lib/constants";

export default function ContactPage() {
  const [form, setForm] = useState({ name: "", phone: "", email: "", subject: "", message: "" });
  const [submitted, setSubmitted] = useState(false);
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      await fetch("/api/contact", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      });
      setSubmitted(true);
    } catch { /* ignore */ }
    setLoading(false);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />

      {/* Hero */}
      <section className="bg-gradient-to-l from-blue-800 to-blue-900 py-16 md:py-24">
        <div className="max-w-7xl mx-auto px-4 text-center">
          <h1 className="text-4xl md:text-5xl font-black text-white mb-4">تماس با ما</h1>
          <p className="text-blue-200 max-w-lg mx-auto">ما آماده پاسخ‌گویی به سؤالات شما هستیم. از هر طریقی که راحت‌تر هستید با ما در ارتباط باشید.</p>
        </div>
      </section>

      {/* Contact Info Cards */}
      <section className="max-w-7xl mx-auto px-4 -mt-12 relative z-10">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {[
            { icon: "📍", title: "آدرس دفتر مرکزی", info: COMPANY.address },
            { icon: "📞", title: "شماره تماس", info: `${COMPANY.phone}\n${COMPANY.fax}` },
            { icon: "📧", title: "ایمیل و شبکه‌های اجتماعی", info: `${COMPANY.email}\n${COMPANY.instagram}` },
          ].map((item, idx) => (
            <div key={idx} className="bg-white rounded-2xl p-8 border border-gray-100 shadow-lg text-center hover:shadow-xl transition-all">
              <span className="text-4xl mb-4 block">{item.icon}</span>
              <h3 className="text-base font-bold text-gray-900 mb-3">{item.title}</h3>
              <p className="text-sm text-gray-500 leading-7 whitespace-pre-line">{item.info}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Contact Form & Map */}
      <section className="max-w-7xl mx-auto px-4 py-16 md:py-24">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Form */}
          <div className="bg-white rounded-2xl p-8 md:p-10 border border-gray-100 shadow-sm">
            <h2 className="text-2xl font-black text-gray-900 mb-2">فرم تماس</h2>
            <p className="text-sm text-gray-500 mb-8">پیام خود را ارسال کنید، در اسرع وقت پاسخ خواهیم داد</p>

            {submitted ? (
              <div className="text-center py-12">
                <span className="text-5xl mb-4 block">✅</span>
                <h3 className="text-xl font-bold text-green-600 mb-2">پیام شما با موفقیت ارسال شد</h3>
                <p className="text-sm text-gray-500">کارشناسان ما در اسرع وقت با شما تماس خواهند گرفت</p>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-5">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">نام و نام خانوادگی *</label>
                    <input
                      type="text"
                      required
                      value={form.name}
                      onChange={(e) => setForm({ ...form, name: e.target.value })}
                      className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                      placeholder="نام خود را وارد کنید"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">شماره تماس *</label>
                    <input
                      type="tel"
                      required
                      value={form.phone}
                      onChange={(e) => setForm({ ...form, phone: e.target.value })}
                      className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                      placeholder="۰۹۱۲۳۴۵۶۷۸۹"
                      dir="ltr"
                    />
                  </div>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">ایمیل</label>
                    <input
                      type="email"
                      value={form.email}
                      onChange={(e) => setForm({ ...form, email: e.target.value })}
                      className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                      placeholder="example@email.com"
                      dir="ltr"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">موضوع</label>
                    <select
                      value={form.subject}
                      onChange={(e) => setForm({ ...form, subject: e.target.value })}
                      className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    >
                      <option value="">انتخاب کنید</option>
                      <option value="sales">فروش و مشاوره</option>
                      <option value="support">خدمات پس از فروش</option>
                      <option value="warranty">گارانتی</option>
                      <option value="cooperation">همکاری</option>
                      <option value="complaint">شکایات</option>
                      <option value="other">سایر</option>
                    </select>
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">پیام *</label>
                  <textarea
                    required
                    rows={5}
                    value={form.message}
                    onChange={(e) => setForm({ ...form, message: e.target.value })}
                    className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent resize-none"
                    placeholder="متن پیام خود را بنویسید..."
                  />
                </div>
                <button
                  type="submit"
                  disabled={loading}
                  className="w-full py-3.5 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-xl transition-colors shadow-lg disabled:opacity-50"
                >
                  {loading ? "در حال ارسال..." : "ارسال پیام"}
                </button>
              </form>
            )}
          </div>

          {/* Map */}
          <div className="rounded-2xl overflow-hidden shadow-sm border border-gray-100 h-[500px] lg:h-auto">
            <iframe
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3239.895!2d51.4!3d35.75!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zMzXCsDQ1JzAwLjAiTiA1McKwMjQnMDAuMCJF!5e0!3m2!1sfa!2sir!4v1"
              className="w-full h-full border-0"
              allowFullScreen
              loading="lazy"
              title="نقشه"
            />
          </div>
        </div>
      </section>

      {/* Working Hours */}
      <section className="max-w-7xl mx-auto px-4 pb-16">
        <div className="bg-gradient-to-l from-gray-900 to-gray-800 rounded-2xl p-8 md:p-12 text-center">
          <h3 className="text-2xl font-black text-white mb-4">ساعات کاری</h3>
          <p className="text-gray-300 text-sm mb-6">{COMPANY.workHours}</p>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 max-w-2xl mx-auto">
            <div className="bg-white/10 rounded-xl p-4">
              <h4 className="text-white font-bold text-sm mb-1">شنبه تا چهارشنبه</h4>
              <p className="text-gray-400 text-xs">۸:۳۰ الی ۱۷:۰۰</p>
            </div>
            <div className="bg-white/10 rounded-xl p-4">
              <h4 className="text-white font-bold text-sm mb-1">پنج‌شنبه</h4>
              <p className="text-gray-400 text-xs">۸:۳۰ الی ۱۳:۰۰</p>
            </div>
            <div className="bg-white/10 rounded-xl p-4">
              <h4 className="text-white font-bold text-sm mb-1">جمعه و تعطیلات</h4>
              <p className="text-gray-400 text-xs">تعطیل</p>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
