"use client";

import Header from "@/components/Header";
import Footer from "@/components/Footer";
import ProductCard from "@/components/ProductCard";
import { SAMPLE_PRODUCTS } from "@/lib/constants";

export default function WishlistPage() {
  const wishlistItems = SAMPLE_PRODUCTS.slice(0, 4);
  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      <div className="max-w-7xl mx-auto px-4 py-8">
        <h1 className="text-3xl font-black text-gray-900 mb-8">علاقه‌مندی‌ها</h1>
        {wishlistItems.length > 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {wishlistItems.map((p) => <ProductCard key={p.id} product={p} />)}
          </div>
        ) : (
          <div className="bg-white rounded-2xl p-16 text-center border border-gray-100">
            <span className="text-5xl mb-4 block">💝</span>
            <h3 className="text-lg font-bold text-gray-800 mb-2">لیست علاقه‌مندی شما خالی است</h3>
            <p className="text-sm text-gray-500">محصولات مورد علاقه خود را به این لیست اضافه کنید</p>
          </div>
        )}
      </div>
      <Footer />
    </div>
  );
}
