"use client";

import Link from "next/link";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { SAMPLE_PRODUCTS } from "@/lib/constants";
import { formatPriceToman, toFarsiNumber } from "@/lib/utils";

export default function CartPage() {
  const cartItems = SAMPLE_PRODUCTS.slice(0, 3).map((p) => ({
    ...p,
    quantity: 1,
    finalPrice: p.discountPrice || p.price,
  }));
  const subtotal = cartItems.reduce((sum, item) => sum + item.finalPrice * item.quantity, 0);
  const shipping = 0;
  const total = subtotal + shipping;

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      <div className="max-w-7xl mx-auto px-4 py-8">
        <div className="flex items-center gap-2 text-sm text-gray-500 mb-8">
          <Link href="/" className="hover:text-blue-600">صفحه اصلی</Link>
          <span>/</span>
          <span className="text-gray-800 font-medium">سبد خرید</span>
        </div>

        <h1 className="text-3xl font-black text-gray-900 mb-8">سبد خرید</h1>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Cart Items */}
          <div className="lg:col-span-2 space-y-4">
            {cartItems.map((item) => (
              <div key={item.id} className="bg-white rounded-2xl border border-gray-100 p-5 flex gap-5">
                <div className="w-28 h-28 rounded-xl overflow-hidden flex-shrink-0">
                  <img src={item.image} alt={item.name} className="w-full h-full object-cover" />
                </div>
                <div className="flex-1">
                  <Link href={`/products/${item.slug}`} className="text-base font-bold text-gray-800 hover:text-blue-600 transition-colors">{item.name}</Link>
                  <p className="text-xs text-gray-500 mt-1">{item.category} | {item.color}</p>
                  <div className="flex items-center justify-between mt-4">
                    <div className="flex items-center border border-gray-200 rounded-xl overflow-hidden">
                      <button className="px-3 py-2 text-gray-600 hover:bg-gray-50">−</button>
                      <span className="px-3 py-2 font-bold text-sm">{toFarsiNumber(item.quantity)}</span>
                      <button className="px-3 py-2 text-gray-600 hover:bg-gray-50">+</button>
                    </div>
                    <div className="text-left">
                      {item.discountPrice && (
                        <span className="text-xs text-gray-400 line-through block">{formatPriceToman(item.price)}</span>
                      )}
                      <span className="text-base font-black text-blue-600">{formatPriceToman(item.finalPrice)}</span>
                    </div>
                  </div>
                </div>
                <button className="text-gray-400 hover:text-red-500 transition-colors self-start">
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"/></svg>
                </button>
              </div>
            ))}
          </div>

          {/* Summary */}
          <div>
            <div className="bg-white rounded-2xl border border-gray-100 p-6 sticky top-24">
              <h3 className="text-lg font-bold text-gray-900 mb-6">خلاصه سفارش</h3>
              
              {/* Coupon */}
              <div className="mb-6">
                <label className="block text-sm font-medium text-gray-700 mb-2">کد تخفیف</label>
                <div className="flex gap-2">
                  <input type="text" placeholder="کد تخفیف را وارد کنید" className="flex-1 px-4 py-2.5 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500" />
                  <button className="px-4 py-2.5 bg-gray-900 text-white text-xs font-bold rounded-xl hover:bg-gray-800 transition-colors">اعمال</button>
                </div>
              </div>

              <div className="space-y-3 mb-6">
                <div className="flex justify-between text-sm">
                  <span className="text-gray-500">جمع سبد خرید</span>
                  <span className="font-medium text-gray-800">{formatPriceToman(subtotal)}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-gray-500">هزینه ارسال</span>
                  <span className="font-medium text-green-600">رایگان</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-gray-500">تخفیف</span>
                  <span className="font-medium text-red-500">-{formatPriceToman(subtotal - total + shipping)}</span>
                </div>
                <div className="border-t border-gray-100 pt-3">
                  <div className="flex justify-between">
                    <span className="font-bold text-gray-800">مبلغ قابل پرداخت</span>
                    <span className="text-xl font-black text-blue-600">{formatPriceToman(total)}</span>
                  </div>
                </div>
              </div>

              <Link href="/checkout" className="block w-full py-3.5 bg-blue-600 hover:bg-blue-700 text-white font-bold text-center rounded-xl transition-colors shadow-lg">
                ادامه فرآیند خرید
              </Link>
              <Link href="/products" className="block w-full py-3 text-center text-sm text-gray-500 hover:text-blue-600 transition-colors mt-3">
                ادامه خرید
              </Link>
            </div>
          </div>
        </div>
      </div>
      <Footer />
    </div>
  );
}
