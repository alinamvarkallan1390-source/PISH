import Header from "@/components/Header";
import Footer from "@/components/Footer";

export default function TermsPage() {
  return (
    <div className="min-h-screen">
      <Header />
      <div className="max-w-3xl mx-auto px-4 py-16">
        <h1 className="text-3xl font-black text-gray-900 mb-8">شرایط و قوانین استفاده</h1>
        <div className="bg-white rounded-2xl p-8 border border-gray-100 space-y-6 text-sm text-gray-600 leading-8">
          <section>
            <h2 className="text-lg font-bold text-gray-900 mb-3">۱. شرایط عمومی</h2>
            <p>استفاده از وب‌سایت پارس‌تک به منزله پذیرش تمامی قوانین و مقررات ذکر شده در این صفحه است. کاربران موظف هستند قبل از استفاده از خدمات، این قوانین را مطالعه کنند.</p>
          </section>
          <section>
            <h2 className="text-lg font-bold text-gray-900 mb-3">۲. شرایط خرید</h2>
            <p>تمامی قیمت‌ها به تومان و شامل مالیات بر ارزش افزوده هستند. قیمت‌ها ممکن است بدون اطلاع قبلی تغییر کنند. تکمیل سفارش منوط به موجودی کالا در انبار است.</p>
          </section>
          <section>
            <h2 className="text-lg font-bold text-gray-900 mb-3">۳. شرایط ارسال</h2>
            <p>ارسال سفارشات در سراسر ایران انجام می‌شود. برای سفارشات بالای ۵ میلیون تومان، ارسال رایگان است. زمان تحویل بسته به مقصد، ۲ تا ۷ روز کاری است.</p>
          </section>
          <section>
            <h2 className="text-lg font-bold text-gray-900 mb-3">۴. شرایط مرجوعی</h2>
            <p>امکان مرجوع کالا تا ۷ روز پس از دریافت و با شرایط اولیه (بدون استفاده و با بسته‌بندی اصلی) وجود دارد.</p>
          </section>
          <section>
            <h2 className="text-lg font-bold text-gray-900 mb-3">۵. گارانتی</h2>
            <p>تمامی محصولات دارای گارانتی اصل هستند. مدت و شرایط گارانتی در صفحه هر محصول ذکر شده است.</p>
          </section>
        </div>
      </div>
      <Footer />
    </div>
  );
}
