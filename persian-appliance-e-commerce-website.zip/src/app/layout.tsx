import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "پارس‌تک | فناوری برتر، زندگی بهتر - لوازم خانگی",
  description: "شرکت صنعتی پارس‌تک، تولیدکننده برتر لوازم خانگی ایران. یخچال، لباسشویی، ظرفشویی، اجاق گاز و لوازم آشپزخانه با کیفیت جهانی.",
  keywords: "لوازم خانگی، یخچال، لباسشویی، ظرفشویی، اجاق گاز، پارس‌تک",
  openGraph: {
    title: "پارس‌تک | لوازم خانگی",
    description: "تولیدکننده برتر لوازم خانگی ایران",
    locale: "fa_IR",
    type: "website",
  },
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="fa" dir="rtl">
      <body className="bg-white text-gray-900 antialiased dark-transition">
        {children}
      </body>
    </html>
  );
}
