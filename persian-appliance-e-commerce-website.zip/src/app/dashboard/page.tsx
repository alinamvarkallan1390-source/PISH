"use client";

import { useState } from "react";
import Link from "next/link";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { toFarsiNumber, formatPriceToman } from "@/lib/utils";

const menuItems = [
  { id: "overview", label: "نمای کلی", icon: "🏠" },
  { id: "orders", label: "سفارشات", icon: "📦" },
  { id: "addresses", label: "آدرس‌ها", icon: "📍" },
  { id: "wishlist", label: "علاقه‌مندی‌ها", icon: "❤️" },
  { id: "profile", label: "اطلاعات حساب", icon: "👤" },
  { id: "tickets", label: "تیکت پشتیبانی", icon: "🎫" },
  { id: "warranty", label: "درخواست گارانتی", icon: "🛡️" },
  { id: "notifications", label: "اعلان‌ها", icon: "🔔" },
];

const sampleOrders = [
  { id: "PT-140401001", date: "۱۵ اردیبهشت ۱۴۰۴", total: 76075000, status: "تحویل شده", statusColor: "green" },
  { id: "PT-140401002", date: "۲۰ اردیبهشت ۱۴۰۴", total: 38520000, status: "در حال ارسال", statusColor: "blue" },
  { id: "PT-140401003", date: "۲۵ اردیبهشت ۱۴۰۴", total: 15120000, status: "در انتظار پرداخت", statusColor: "yellow" },
];

export default function DashboardPage() {
  const [activeMenu, setActiveMenu] = useState("overview");

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      <div className="max-w-7xl mx-auto px-4 py-8">
        <h1 className="text-2xl font-black text-gray-900 mb-8">حساب کاربری</h1>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* Sidebar */}
          <aside>
            <div className="bg-white rounded-2xl border border-gray-100 p-5">
              {/* User Info */}
              <div className="flex items-center gap-3 mb-6 pb-6 border-b border-gray-100">
                <div className="w-14 h-14 bg-gradient-to-br from-blue-500 to-blue-700 rounded-full flex items-center justify-center text-white text-xl font-bold">م</div>
                <div>
                  <h3 className="font-bold text-gray-900">محمد احمدی</h3>
                  <p className="text-xs text-gray-500" dir="ltr">09123456789</p>
                </div>
              </div>
              <nav className="space-y-1">
                {menuItems.map((item) => (
                  <button
                    key={item.id}
                    onClick={() => setActiveMenu(item.id)}
                    className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm transition-all ${
                      activeMenu === item.id
                        ? "bg-blue-50 text-blue-600 font-medium"
                        : "text-gray-600 hover:bg-gray-50"
                    }`}
                  >
                    <span>{item.icon}</span>
                    {item.label}
                  </button>
                ))}
                <button className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm text-red-500 hover:bg-red-50 transition-all">
                  <span>🚪</span>
                  خروج از حساب
                </button>
              </nav>
            </div>
          </aside>

          {/* Content */}
          <div className="lg:col-span-3">
            {activeMenu === "overview" && (
              <div>
                {/* Stats */}
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
                  {[
                    { label: "سفارشات", value: "۱۲", icon: "📦", color: "blue" },
                    { label: "علاقه‌مندی", value: "۸", icon: "❤️", color: "red" },
                    { label: "امتیاز", value: "۲٬۴۵۰", icon: "⭐", color: "yellow" },
                    { label: "تیکت", value: "۲", icon: "🎫", color: "green" },
                  ].map((stat, idx) => (
                    <div key={idx} className="bg-white rounded-2xl p-5 border border-gray-100 text-center">
                      <span className="text-2xl mb-2 block">{stat.icon}</span>
                      <h4 className="text-2xl font-black text-gray-900">{stat.value}</h4>
                      <p className="text-xs text-gray-500 mt-1">{stat.label}</p>
                    </div>
                  ))}
                </div>

                {/* Recent Orders */}
                <div className="bg-white rounded-2xl border border-gray-100 p-6">
                  <h3 className="text-lg font-bold text-gray-900 mb-4">آخرین سفارشات</h3>
                  <div className="overflow-x-auto">
                    <table className="w-full">
                      <thead>
                        <tr className="text-xs text-gray-500 border-b border-gray-100">
                          <th className="text-right pb-3 font-medium">شماره سفارش</th>
                          <th className="text-right pb-3 font-medium">تاریخ</th>
                          <th className="text-right pb-3 font-medium">مبلغ</th>
                          <th className="text-right pb-3 font-medium">وضعیت</th>
                        </tr>
                      </thead>
                      <tbody>
                        {sampleOrders.map((order) => (
                          <tr key={order.id} className="border-b border-gray-50 last:border-0">
                            <td className="py-4 text-sm font-medium text-gray-800">{order.id}</td>
                            <td className="py-4 text-sm text-gray-500">{order.date}</td>
                            <td className="py-4 text-sm font-bold text-gray-800">{formatPriceToman(order.total)}</td>
                            <td className="py-4">
                              <span className={`px-3 py-1 text-xs font-medium rounded-full ${
                                order.statusColor === "green" ? "bg-green-100 text-green-700" :
                                order.statusColor === "blue" ? "bg-blue-100 text-blue-700" :
                                "bg-yellow-100 text-yellow-700"
                              }`}>
                                {order.status}
                              </span>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            )}

            {activeMenu === "orders" && (
              <div className="bg-white rounded-2xl border border-gray-100 p-6">
                <h3 className="text-lg font-bold text-gray-900 mb-6">سفارشات من</h3>
                <div className="space-y-4">
                  {sampleOrders.map((order) => (
                    <div key={order.id} className="border border-gray-100 rounded-xl p-5 hover:shadow-md transition-all">
                      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                        <div>
                          <h4 className="font-bold text-gray-800 mb-1">سفارش {order.id}</h4>
                          <p className="text-xs text-gray-500">{order.date}</p>
                        </div>
                        <div className="flex items-center gap-4">
                          <span className="text-base font-black text-gray-800">{formatPriceToman(order.total)}</span>
                          <span className={`px-3 py-1.5 text-xs font-medium rounded-full ${
                            order.statusColor === "green" ? "bg-green-100 text-green-700" :
                            order.statusColor === "blue" ? "bg-blue-100 text-blue-700" :
                            "bg-yellow-100 text-yellow-700"
                          }`}>
                            {order.status}
                          </span>
                          <button className="text-sm text-blue-600 hover:text-blue-700 font-medium">جزئیات</button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {activeMenu === "profile" && (
              <div className="bg-white rounded-2xl border border-gray-100 p-6 md:p-8">
                <h3 className="text-lg font-bold text-gray-900 mb-6">اطلاعات حساب کاربری</h3>
                <div className="space-y-5 max-w-lg">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">نام و نام خانوادگی</label>
                    <input type="text" defaultValue="محمد احمدی" className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">شماره تماس</label>
                    <input type="tel" defaultValue="09123456789" dir="ltr" className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">ایمیل</label>
                    <input type="email" defaultValue="mohammad@email.com" dir="ltr" className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500" />
                  </div>
                  <button className="px-8 py-3 bg-blue-600 hover:bg-blue-700 text-white font-bold text-sm rounded-xl transition-colors">
                    ذخیره تغییرات
                  </button>
                </div>
              </div>
            )}

            {activeMenu !== "overview" && activeMenu !== "orders" && activeMenu !== "profile" && (
              <div className="bg-white rounded-2xl border border-gray-100 p-16 text-center">
                <span className="text-5xl mb-4 block">🚧</span>
                <h3 className="text-lg font-bold text-gray-800 mb-2">
                  {menuItems.find((m) => m.id === activeMenu)?.label}
                </h3>
                <p className="text-sm text-gray-500">این بخش در حال توسعه است</p>
              </div>
            )}
          </div>
        </div>
      </div>
      <Footer />
    </div>
  );
}
