"use client";

import { useState, useEffect } from "react";
import Link from "next/link";
import { toFarsiNumber, formatPriceToman } from "@/lib/utils";

interface Stats {
  products: number;
  orders: number;
  contacts: number;
  dealers: number;
  newsletters: number;
  reviews: number;
}

const sidebarItems = [
  { id: "dashboard", label: "داشبورد", icon: "📊" },
  { id: "products", label: "مدیریت محصولات", icon: "📦" },
  { id: "categories", label: "دسته‌بندی‌ها", icon: "📂" },
  { id: "orders", label: "سفارشات", icon: "🛒" },
  { id: "customers", label: "مشتریان", icon: "👥" },
  { id: "dealers", label: "درخواست نمایندگی", icon: "🏪" },
  { id: "cooperation", label: "درخواست همکاری", icon: "🤝" },
  { id: "blog", label: "مدیریت بلاگ", icon: "📝" },
  { id: "reviews", label: "نظرات", icon: "💬" },
  { id: "messages", label: "پیام‌ها", icon: "📧" },
  { id: "sliders", label: "اسلایدرها", icon: "🖼️" },
  { id: "coupons", label: "کدهای تخفیف", icon: "🎟️" },
  { id: "reports", label: "گزارشات", icon: "📈" },
  { id: "settings", label: "تنظیمات", icon: "⚙️" },
];

const recentOrders = [
  { id: "PT-001", customer: "علی محمدی", total: 76075000, status: "تکمیل شده", date: "۱۵ اردیبهشت" },
  { id: "PT-002", customer: "فاطمه رضایی", total: 38520000, status: "در حال ارسال", date: "۱۴ اردیبهشت" },
  { id: "PT-003", customer: "حسین کریمی", total: 44455000, status: "در انتظار", date: "۱۳ اردیبهشت" },
  { id: "PT-004", customer: "زهرا احمدی", total: 15120000, status: "پرداخت شده", date: "۱۲ اردیبهشت" },
  { id: "PT-005", customer: "محمد حسینی", total: 35600000, status: "تکمیل شده", date: "۱۱ اردیبهشت" },
];

export default function AdminPage() {
  const [activeMenu, setActiveMenu] = useState("dashboard");
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [stats, setStats] = useState<Stats>({ products: 0, orders: 0, contacts: 0, dealers: 0, newsletters: 0, reviews: 0 });

  useEffect(() => {
    fetch("/api/admin/stats")
      .then((r) => r.json())
      .then((data) => setStats(data))
      .catch(() => {});
  }, []);

  return (
    <div className="min-h-screen bg-gray-100 flex" dir="rtl">
      {/* Sidebar */}
      <aside className={`${sidebarOpen ? 'w-64' : 'w-20'} bg-gray-900 min-h-screen transition-all duration-300 flex-shrink-0 fixed right-0 top-0 z-50 h-full`}>
        <div className="p-5 flex items-center justify-between border-b border-gray-800">
          {sidebarOpen && (
            <Link href="/" className="flex items-center gap-2">
              <div className="w-9 h-9 bg-blue-600 rounded-xl flex items-center justify-center text-white font-bold text-sm">PT</div>
              <span className="text-white font-bold text-sm">پنل مدیریت</span>
            </Link>
          )}
          <button onClick={() => setSidebarOpen(!sidebarOpen)} className="text-gray-400 hover:text-white transition-colors p-1">
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16"/></svg>
          </button>
        </div>
        <nav className="p-3 space-y-1 overflow-y-auto max-h-[calc(100vh-80px)]">
          {sidebarItems.map((item) => (
            <button
              key={item.id}
              onClick={() => setActiveMenu(item.id)}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm transition-all ${
                activeMenu === item.id
                  ? "bg-blue-600 text-white"
                  : "text-gray-400 hover:bg-gray-800 hover:text-white"
              }`}
            >
              <span className="text-lg">{item.icon}</span>
              {sidebarOpen && <span>{item.label}</span>}
            </button>
          ))}
        </nav>
      </aside>

      {/* Main */}
      <main className={`flex-1 ${sidebarOpen ? 'mr-64' : 'mr-20'} transition-all duration-300`}>
        {/* Top Bar */}
        <header className="bg-white border-b border-gray-200 px-6 py-4 flex items-center justify-between sticky top-0 z-40">
          <div>
            <h1 className="text-lg font-bold text-gray-900">
              {sidebarItems.find((i) => i.id === activeMenu)?.label}
            </h1>
            <p className="text-xs text-gray-500 mt-0.5">۱۵ اردیبهشت ۱۴۰۴ — خوش آمدید، مدیر</p>
          </div>
          <div className="flex items-center gap-3">
            <Link href="/" className="px-4 py-2 bg-gray-100 text-gray-700 text-xs font-medium rounded-xl hover:bg-gray-200 transition-colors">
              مشاهده سایت
            </Link>
            <button className="relative p-2 text-gray-500 hover:text-gray-700 transition-colors">
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9"/></svg>
              <span className="absolute top-1 right-1 w-2 h-2 bg-red-500 rounded-full"></span>
            </button>
            <div className="w-9 h-9 bg-blue-600 rounded-full flex items-center justify-center text-white text-xs font-bold">ا</div>
          </div>
        </header>

        <div className="p-6">
          {activeMenu === "dashboard" && (
            <>
              {/* Stats Cards */}
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4 mb-8">
                {[
                  { label: "محصولات", value: stats.products || 350, icon: "📦", trend: "+۱۲", color: "blue" },
                  { label: "سفارشات", value: stats.orders || 1248, icon: "🛒", trend: "+۲۸", color: "green" },
                  { label: "مشتریان", value: 4520, icon: "👥", trend: "+۱۵۶", color: "purple" },
                  { label: "درآمد ماهانه", value: 0, icon: "💰", trend: "+۱۸%", color: "yellow", isPrice: true, priceValue: 2850000000 },
                  { label: "نمایندگی‌ها", value: stats.dealers || 1200, icon: "🏪", trend: "+۵", color: "orange" },
                  { label: "پیام‌ها", value: stats.contacts || 34, icon: "📧", trend: "+۸", color: "red" },
                ].map((stat, idx) => (
                  <div key={idx} className="bg-white rounded-2xl p-5 border border-gray-100 hover:shadow-lg transition-all">
                    <div className="flex items-center justify-between mb-3">
                      <span className="text-2xl">{stat.icon}</span>
                      <span className="text-xs text-green-600 font-medium bg-green-50 px-2 py-0.5 rounded-full">{stat.trend}</span>
                    </div>
                    <h4 className="text-2xl font-black text-gray-900">
                      {stat.isPrice ? formatPriceToman(stat.priceValue!) : toFarsiNumber(stat.value)}
                    </h4>
                    <p className="text-xs text-gray-500 mt-1">{stat.label}</p>
                  </div>
                ))}
              </div>

              {/* Charts / Orders */}
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
                {/* Revenue Chart Placeholder */}
                <div className="lg:col-span-2 bg-white rounded-2xl p-6 border border-gray-100">
                  <h3 className="text-base font-bold text-gray-900 mb-6">نمودار فروش ماهانه</h3>
                  <div className="h-64 flex items-end justify-between gap-2 px-4">
                    {[65, 45, 80, 55, 90, 70, 85, 60, 95, 75, 88, 92].map((h, idx) => (
                      <div key={idx} className="flex-1 flex flex-col items-center gap-2">
                        <div
                          className="w-full bg-gradient-to-t from-blue-600 to-blue-400 rounded-t-lg transition-all hover:from-blue-700 hover:to-blue-500 cursor-pointer"
                          style={{ height: `${h}%` }}
                        />
                        <span className="text-[10px] text-gray-400">
                          {["فرو", "ارد", "خرد", "تیر", "مرد", "شهر", "مهر", "آبا", "آذر", "دی", "بهم", "اسف"][idx]}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Status */}
                <div className="bg-white rounded-2xl p-6 border border-gray-100">
                  <h3 className="text-base font-bold text-gray-900 mb-6">وضعیت سفارشات</h3>
                  <div className="space-y-4">
                    {[
                      { label: "تکمیل شده", value: 856, percent: 68, color: "bg-green-500" },
                      { label: "در حال ارسال", value: 234, percent: 19, color: "bg-blue-500" },
                      { label: "در انتظار", value: 98, percent: 8, color: "bg-yellow-500" },
                      { label: "لغو شده", value: 60, percent: 5, color: "bg-red-500" },
                    ].map((item, idx) => (
                      <div key={idx}>
                        <div className="flex justify-between text-sm mb-1.5">
                          <span className="text-gray-600">{item.label}</span>
                          <span className="font-bold text-gray-800">{toFarsiNumber(item.value)}</span>
                        </div>
                        <div className="w-full h-2 bg-gray-100 rounded-full overflow-hidden">
                          <div className={`h-full ${item.color} rounded-full transition-all`} style={{ width: `${item.percent}%` }} />
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              {/* Recent Orders Table */}
              <div className="bg-white rounded-2xl border border-gray-100 p-6">
                <div className="flex items-center justify-between mb-6">
                  <h3 className="text-base font-bold text-gray-900">آخرین سفارشات</h3>
                  <button className="text-sm text-blue-600 hover:text-blue-700 font-medium">مشاهده همه</button>
                </div>
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="text-xs text-gray-500 border-b border-gray-100">
                        <th className="text-right pb-3 font-medium">شماره</th>
                        <th className="text-right pb-3 font-medium">مشتری</th>
                        <th className="text-right pb-3 font-medium">مبلغ</th>
                        <th className="text-right pb-3 font-medium">وضعیت</th>
                        <th className="text-right pb-3 font-medium">تاریخ</th>
                        <th className="text-right pb-3 font-medium">عملیات</th>
                      </tr>
                    </thead>
                    <tbody>
                      {recentOrders.map((order) => (
                        <tr key={order.id} className="border-b border-gray-50 last:border-0 hover:bg-gray-50 transition-colors">
                          <td className="py-4 text-sm font-medium text-blue-600">{order.id}</td>
                          <td className="py-4 text-sm text-gray-800">{order.customer}</td>
                          <td className="py-4 text-sm font-bold text-gray-800">{formatPriceToman(order.total)}</td>
                          <td className="py-4">
                            <span className={`px-2.5 py-1 text-[10px] font-medium rounded-full ${
                              order.status === "تکمیل شده" ? "bg-green-100 text-green-700" :
                              order.status === "در حال ارسال" ? "bg-blue-100 text-blue-700" :
                              order.status === "پرداخت شده" ? "bg-purple-100 text-purple-700" :
                              "bg-yellow-100 text-yellow-700"
                            }`}>
                              {order.status}
                            </span>
                          </td>
                          <td className="py-4 text-xs text-gray-500">{order.date}</td>
                          <td className="py-4">
                            <button className="text-xs text-gray-500 hover:text-blue-600 transition-colors">جزئیات</button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </>
          )}

          {activeMenu !== "dashboard" && (
            <div className="bg-white rounded-2xl border border-gray-100 p-16 text-center">
              <span className="text-6xl mb-4 block">
                {sidebarItems.find((i) => i.id === activeMenu)?.icon}
              </span>
              <h2 className="text-xl font-black text-gray-800 mb-2">
                {sidebarItems.find((i) => i.id === activeMenu)?.label}
              </h2>
              <p className="text-sm text-gray-500 mb-6">این بخش آماده پیاده‌سازی کامل است</p>
              <button onClick={() => setActiveMenu("dashboard")} className="px-6 py-2.5 bg-blue-600 text-white text-sm font-bold rounded-xl hover:bg-blue-700 transition-colors">
                بازگشت به داشبورد
              </button>
            </div>
          )}
        </div>
      </main>
    </div>
  );
}
