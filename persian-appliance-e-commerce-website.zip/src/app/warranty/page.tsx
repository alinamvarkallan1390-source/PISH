"use client";

import { useState } from "react";
import Header from "@/components/Header";
import Footer from "@/components/Footer";

export default function WarrantyPage() {
  const [submitted, setSubmitted] = useState(false);

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      <section className="bg-gradient-to-l from-blue-800 to-blue-900 py-16 md:py-24">
        <div className="max-w-7xl mx-auto px-4 text-center">
          <h1 className="text-4xl md:text-5xl font-black text-white mb-4">ثبت گارانتی</h1>
          <p className="text-blue-200 max-w-lg mx-auto">با ثبت اطلاعات محصول خود، از خدمات گارانتی پارس‌تک بهره‌مند شوید</p>
        </div>
      </section>

      <section className="max-w-2xl mx-auto px-4 py-16">
        <div className="bg-white rounded-2xl p-8 md:p-10 border border-gray-100 shadow-sm">
          {submitted ? (
            <div className="text-center py-12">
              <span className="text-6xl mb-4 block">🛡️</span>
              <h2 className="text-2xl font-black text-green-600 mb-3">گارانتی با موفقیت ثبت شد</h2>
              <p className="text-gray-500 text-sm">اطلاعات گارانتی محصول شما در سیستم ثبت گردید</p>
            </div>
          ) : (
            <form onSubmit={(e) => { e.preventDefault(); setSubmitted(true); }} className="space-y-5">
              <h2 className="text-xl font-black text-gray-900 mb-4">اطلاعات محصول</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">نام و نام خانوادگی *</label>
                  <input type="text" required className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">شماره تماس *</label>
                  <input type="tel" required dir="ltr" className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">مدل محصول *</label>
                  <input type="text" required className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500" placeholder="مثال: PT-S700" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">شماره سریال *</label>
                  <input type="text" required dir="ltr" className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">تاریخ خرید *</label>
                  <input type="text" required className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500" placeholder="مثال: ۱۴۰۴/۰۲/۱۵" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">محل خرید</label>
                  <input type="text" className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500" placeholder="نام فروشگاه" />
                </div>
              </div>
              <button type="submit" className="w-full py-3.5 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-xl transition-colors shadow-lg">
                ثبت گارانتی
              </button>
            </form>
          )}
        </div>
      </section>

      <Footer />
    </div>
  );
}
