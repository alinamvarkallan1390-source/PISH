"use client";

import { useState } from "react";
import Link from "next/link";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { PROVINCES, SAMPLE_PRODUCTS } from "@/lib/constants";
import { formatPriceToman } from "@/lib/utils";

export default function CheckoutPage() {
  const [step, setStep] = useState(1);
  const [paymentMethod, setPaymentMethod] = useState("online");

  const cartItems = SAMPLE_PRODUCTS.slice(0, 2);
  const total = cartItems.reduce((sum, p) => sum + (p.discountPrice || p.price), 0);

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      <div className="max-w-5xl mx-auto px-4 py-8">
        {/* Steps */}
        <div className="flex items-center justify-center mb-10">
          {["اطلاعات ارسال", "روش پرداخت", "تأیید نهایی"].map((s, idx) => (
            <div key={idx} className="flex items-center">
              <div className={`flex items-center gap-2 px-4 py-2 rounded-full text-sm font-medium ${
                step > idx + 1 ? "bg-green-100 text-green-700" :
                step === idx + 1 ? "bg-blue-600 text-white" :
                "bg-gray-100 text-gray-400"
              }`}>
                <span className="w-6 h-6 rounded-full bg-white/20 flex items-center justify-center text-xs font-bold">
                  {step > idx + 1 ? "✓" : idx + 1}
                </span>
                <span className="hidden sm:inline">{s}</span>
              </div>
              {idx < 2 && <div className="w-8 md:w-16 h-0.5 bg-gray-200 mx-2" />}
            </div>
          ))}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2">
            {/* Step 1: Shipping */}
            {step === 1 && (
              <div className="bg-white rounded-2xl p-6 md:p-8 border border-gray-100">
                <h2 className="text-xl font-black text-gray-900 mb-6">اطلاعات ارسال</h2>
                <div className="space-y-5">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">نام و نام خانوادگی *</label>
                      <input type="text" className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500" />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">شماره تماس *</label>
                      <input type="tel" dir="ltr" className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500" />
                    </div>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">استان *</label>
                      <select className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500">
                        <option value="">انتخاب استان</option>
                        {PROVINCES.map((p) => <option key={p}>{p}</option>)}
                      </select>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">شهر *</label>
                      <input type="text" className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500" />
                    </div>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">آدرس کامل *</label>
                    <textarea rows={3} className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 resize-none" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">کد پستی *</label>
                    <input type="text" dir="ltr" className="w-full md:w-1/2 px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500" />
                  </div>
                  <button onClick={() => setStep(2)} className="w-full py-3.5 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-xl transition-colors shadow-lg">
                    ادامه — انتخاب روش پرداخت
                  </button>
                </div>
              </div>
            )}

            {/* Step 2: Payment */}
            {step === 2 && (
              <div className="bg-white rounded-2xl p-6 md:p-8 border border-gray-100">
                <h2 className="text-xl font-black text-gray-900 mb-6">روش پرداخت</h2>
                <div className="space-y-3 mb-6">
                  {[
                    { id: "online", label: "پرداخت آنلاین", desc: "پرداخت از طریق درگاه بانکی", icon: "💳" },
                    { id: "card", label: "کارت به کارت", desc: "واریز به شماره کارت", icon: "🏧" },
                    { id: "wallet", label: "کیف پول", desc: "پرداخت از موجودی کیف پول", icon: "👛" },
                  ].map((method) => (
                    <button
                      key={method.id}
                      onClick={() => setPaymentMethod(method.id)}
                      className={`w-full flex items-center gap-4 p-5 rounded-xl border-2 transition-all text-right ${
                        paymentMethod === method.id
                          ? "border-blue-600 bg-blue-50"
                          : "border-gray-200 hover:border-gray-300"
                      }`}
                    >
                      <span className="text-2xl">{method.icon}</span>
                      <div>
                        <h4 className="text-sm font-bold text-gray-800">{method.label}</h4>
                        <p className="text-xs text-gray-500">{method.desc}</p>
                      </div>
                    </button>
                  ))}
                </div>
                <div className="flex gap-3">
                  <button onClick={() => setStep(1)} className="px-6 py-3.5 bg-gray-100 text-gray-700 font-bold text-sm rounded-xl hover:bg-gray-200 transition-colors">
                    بازگشت
                  </button>
                  <button onClick={() => setStep(3)} className="flex-1 py-3.5 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-xl transition-colors shadow-lg">
                    ادامه — تأیید نهایی
                  </button>
                </div>
              </div>
            )}

            {/* Step 3: Confirm */}
            {step === 3 && (
              <div className="bg-white rounded-2xl p-6 md:p-8 border border-gray-100">
                <h2 className="text-xl font-black text-gray-900 mb-6">تأیید نهایی سفارش</h2>
                <div className="space-y-4 mb-6">
                  {cartItems.map((item) => (
                    <div key={item.id} className="flex items-center gap-4 p-4 bg-gray-50 rounded-xl">
                      <img src={item.image} alt={item.name} className="w-16 h-16 rounded-xl object-cover" />
                      <div className="flex-1">
                        <h4 className="text-sm font-bold text-gray-800">{item.name}</h4>
                        <p className="text-xs text-gray-500">{item.category}</p>
                      </div>
                      <span className="font-bold text-blue-600 text-sm">{formatPriceToman(item.discountPrice || item.price)}</span>
                    </div>
                  ))}
                </div>
                <div className="flex gap-3">
                  <button onClick={() => setStep(2)} className="px-6 py-3.5 bg-gray-100 text-gray-700 font-bold text-sm rounded-xl hover:bg-gray-200 transition-colors">
                    بازگشت
                  </button>
                  <button className="flex-1 py-3.5 bg-green-600 hover:bg-green-700 text-white font-bold rounded-xl transition-colors shadow-lg text-center">
                    پرداخت و ثبت سفارش — {formatPriceToman(total)}
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* Order Summary */}
          <div>
            <div className="bg-white rounded-2xl border border-gray-100 p-6 sticky top-24">
              <h3 className="text-base font-bold text-gray-900 mb-4">خلاصه سفارش</h3>
              <div className="space-y-3 text-sm">
                <div className="flex justify-between">
                  <span className="text-gray-500">تعداد اقلام</span>
                  <span className="font-medium">۲ محصول</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-500">هزینه ارسال</span>
                  <span className="font-medium text-green-600">رایگان</span>
                </div>
                <div className="border-t border-gray-100 pt-3">
                  <div className="flex justify-between">
                    <span className="font-bold text-gray-800">جمع کل</span>
                    <span className="text-lg font-black text-blue-600">{formatPriceToman(total)}</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <Footer />
    </div>
  );
}
