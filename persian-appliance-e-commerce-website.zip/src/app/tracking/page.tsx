"use client";

import { useState } from "react";
import Header from "@/components/Header";
import Footer from "@/components/Footer";

export default function TrackingPage() {
  const [orderNumber, setOrderNumber] = useState("");
  const [searched, setSearched] = useState(false);

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      <section className="bg-gradient-to-l from-blue-800 to-blue-900 py-16 md:py-24">
        <div className="max-w-7xl mx-auto px-4 text-center">
          <h1 className="text-4xl md:text-5xl font-black text-white mb-4">پیگیری سفارش</h1>
          <p className="text-blue-200 max-w-lg mx-auto">با وارد کردن شماره سفارش، وضعیت سفارش خود را پیگیری کنید</p>
        </div>
      </section>

      <section className="max-w-xl mx-auto px-4 -mt-8 relative z-10">
        <div className="bg-white rounded-2xl p-8 shadow-xl border border-gray-100">
          <div className="flex gap-3">
            <input
              type="text"
              value={orderNumber}
              onChange={(e) => setOrderNumber(e.target.value)}
              placeholder="شماره سفارش (مثال: PT-140401001)"
              className="flex-1 px-5 py-3.5 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
              dir="ltr"
            />
            <button
              onClick={() => setSearched(true)}
              className="px-6 py-3.5 bg-blue-600 hover:bg-blue-700 text-white font-bold text-sm rounded-xl transition-colors"
            >
              پیگیری
            </button>
          </div>

          {searched && (
            <div className="mt-8">
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-base font-bold text-gray-900">سفارش PT-140401001</h3>
                <span className="px-3 py-1 bg-blue-100 text-blue-700 text-xs font-medium rounded-full">در حال ارسال</span>
              </div>
              <div className="relative">
                {[
                  { step: "ثبت سفارش", date: "۱۵ اردیبهشت ۱۴۰۴", done: true },
                  { step: "تأیید پرداخت", date: "۱۵ اردیبهشت ۱۴۰۴", done: true },
                  { step: "آماده‌سازی", date: "۱۶ اردیبهشت ۱۴۰۴", done: true },
                  { step: "ارسال شده", date: "۱۷ اردیبهشت ۱۴۰۴", done: true },
                  { step: "تحویل به مشتری", date: "-", done: false },
                ].map((item, idx) => (
                  <div key={idx} className="flex gap-4 mb-6 last:mb-0">
                    <div className="flex flex-col items-center">
                      <div className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold ${
                        item.done ? "bg-green-500 text-white" : "bg-gray-200 text-gray-500"
                      }`}>
                        {item.done ? "✓" : idx + 1}
                      </div>
                      {idx < 4 && <div className={`w-0.5 h-8 ${item.done ? "bg-green-300" : "bg-gray-200"}`} />}
                    </div>
                    <div>
                      <h4 className={`text-sm font-bold ${item.done ? "text-gray-900" : "text-gray-400"}`}>{item.step}</h4>
                      <p className="text-xs text-gray-400">{item.date}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </section>

      <div className="py-24" />
      <Footer />
    </div>
  );
}
