"use client";

import Link from "next/link";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import SectionTitle from "@/components/SectionTitle";
import { BLOG_POSTS } from "@/lib/constants";

export default function BlogPage() {
  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      <section className="bg-gradient-to-l from-blue-800 to-blue-900 py-16 md:py-20">
        <div className="max-w-7xl mx-auto px-4 text-center">
          <h1 className="text-4xl md:text-5xl font-black text-white mb-4">بلاگ پارس‌تک</h1>
          <p className="text-blue-200 max-w-lg mx-auto">مقالات آموزشی، راهنمای خرید، نکات نگهداری و آخرین اخبار صنعت لوازم خانگی</p>
        </div>
      </section>

      <section className="max-w-7xl mx-auto px-4 py-16">
        {/* Featured Post */}
        <div className="mb-12">
          <Link href={`/blog/${BLOG_POSTS[0].slug}`} className="group block bg-white rounded-2xl overflow-hidden border border-gray-100 hover:shadow-xl transition-all">
            <div className="grid grid-cols-1 lg:grid-cols-2">
              <div className="aspect-[16/10] lg:aspect-auto overflow-hidden">
                <img src={BLOG_POSTS[0].image} alt={BLOG_POSTS[0].title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
              </div>
              <div className="p-8 md:p-12 flex flex-col justify-center">
                <span className="text-xs text-blue-600 font-medium mb-3">{BLOG_POSTS[0].category}</span>
                <h2 className="text-2xl md:text-3xl font-black text-gray-900 mb-4 group-hover:text-blue-600 transition-colors leading-tight">{BLOG_POSTS[0].title}</h2>
                <p className="text-gray-500 text-sm leading-7 mb-6">{BLOG_POSTS[0].excerpt}</p>
                <div className="flex items-center gap-4 text-xs text-gray-400">
                  <span>{BLOG_POSTS[0].author}</span>
                  <span>•</span>
                  <span>{BLOG_POSTS[0].date}</span>
                  <span>•</span>
                  <span>{BLOG_POSTS[0].readTime} مطالعه</span>
                </div>
              </div>
            </div>
          </Link>
        </div>

        {/* Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {BLOG_POSTS.map((post) => (
            <Link key={post.id} href={`/blog/${post.slug}`} className="group bg-white rounded-2xl overflow-hidden border border-gray-100 hover:shadow-xl hover:border-blue-100 transition-all">
              <div className="aspect-[16/10] overflow-hidden">
                <img src={post.image} alt={post.title} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" loading="lazy" />
              </div>
              <div className="p-6">
                <span className="text-xs text-blue-600 font-medium">{post.category}</span>
                <h3 className="text-base font-bold text-gray-800 mt-2 mb-3 line-clamp-2 group-hover:text-blue-600 transition-colors leading-7">{post.title}</h3>
                <p className="text-xs text-gray-500 line-clamp-2 leading-5 mb-4">{post.excerpt}</p>
                <div className="flex items-center justify-between text-xs text-gray-400 pt-4 border-t border-gray-100">
                  <div className="flex items-center gap-2">
                    <div className="w-6 h-6 bg-blue-100 rounded-full flex items-center justify-center text-blue-600 text-[10px] font-bold">{post.author.charAt(0)}</div>
                    <span>{post.author}</span>
                  </div>
                  <span>{post.date}</span>
                </div>
              </div>
            </Link>
          ))}
        </div>
      </section>

      <Footer />
    </div>
  );
}
