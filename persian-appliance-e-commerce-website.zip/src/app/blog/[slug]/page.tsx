"use client";

import { use } from "react";
import Link from "next/link";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { BLOG_POSTS } from "@/lib/constants";

export default function BlogPostPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = use(params);
  const post = BLOG_POSTS.find((p) => p.slug === slug) || BLOG_POSTS[0];
  const otherPosts = BLOG_POSTS.filter((p) => p.id !== post.id);

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />

      <article className="max-w-4xl mx-auto px-4 py-12">
        {/* Breadcrumb */}
        <div className="flex items-center gap-2 text-sm text-gray-500 mb-8">
          <Link href="/" className="hover:text-blue-600">صفحه اصلی</Link>
          <span>/</span>
          <Link href="/blog" className="hover:text-blue-600">بلاگ</Link>
          <span>/</span>
          <span className="text-gray-800">{post.category}</span>
        </div>

        {/* Header */}
        <div className="mb-8">
          <span className="px-3 py-1 bg-blue-100 text-blue-600 text-xs font-bold rounded-full">{post.category}</span>
          <h1 className="text-3xl md:text-4xl font-black text-gray-900 mt-4 mb-4 leading-tight">{post.title}</h1>
          <div className="flex items-center gap-4 text-sm text-gray-500">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center text-blue-600 text-xs font-bold">{post.author.charAt(0)}</div>
              <span>{post.author}</span>
            </div>
            <span>•</span>
            <span>{post.date}</span>
            <span>•</span>
            <span>{post.readTime} مطالعه</span>
          </div>
        </div>

        {/* Image */}
        <div className="aspect-[16/9] rounded-2xl overflow-hidden mb-10">
          <img src={post.image} alt={post.title} className="w-full h-full object-cover" />
        </div>

        {/* Content */}
        <div className="bg-white rounded-2xl p-8 md:p-12 border border-gray-100 mb-10">
          <div className="prose prose-lg max-w-none text-gray-700 leading-9 text-sm">
            <p className="text-base leading-8 mb-6">{post.excerpt}</p>
            <h2 className="text-xl font-black text-gray-900 mt-8 mb-4">مقدمه</h2>
            <p className="leading-8 mb-4">انتخاب لوازم خانگی مناسب یکی از مهم‌ترین تصمیمات خرید خانواده‌هاست. محصولات خانگی نه تنها بخش بزرگی از بودجه خانوار را به خود اختصاص می‌دهند، بلکه تأثیر مستقیمی بر کیفیت زندگی روزمره دارند.</p>
            <h2 className="text-xl font-black text-gray-900 mt-8 mb-4">نکات مهم در انتخاب</h2>
            <p className="leading-8 mb-4">در هنگام خرید لوازم خانگی، توجه به عوامل مختلفی مانند برند، رده انرژی، ظرفیت، ابعاد، گارانتی و خدمات پس از فروش ضروری است. همچنین مقایسه قیمت‌ها در فروشگاه‌های مختلف می‌تواند به یافتن بهترین پیشنهاد کمک کند.</p>
            <h2 className="text-xl font-black text-gray-900 mt-8 mb-4">فناوری‌های جدید</h2>
            <p className="leading-8 mb-4">فناوری‌های نوینی مانند کمپرسور اینورتر، سیستم‌های هوشمند، اتصال WiFi و سنسورهای پیشرفته، تجربه استفاده از لوازم خانگی را به سطح جدیدی ارتقا داده‌اند. پارس‌تک با بکارگیری این فناوری‌ها، محصولاتی کارآمدتر و هوشمندتر عرضه می‌کند.</p>
            <h2 className="text-xl font-black text-gray-900 mt-8 mb-4">نتیجه‌گیری</h2>
            <p className="leading-8">با تحقیق و مقایسه درست، می‌توانید بهترین لوازم خانگی را متناسب با نیاز و بودجه خود انتخاب کنید. پارس‌تک با ارائه محصولات متنوع و باکیفیت، همراه با خدمات پس از فروش عالی، بهترین انتخاب برای خانواده‌های ایرانی است.</p>
          </div>
        </div>

        {/* Share */}
        <div className="flex items-center gap-4 mb-10">
          <span className="text-sm font-bold text-gray-700">اشتراک‌گذاری:</span>
          <div className="flex gap-2">
            {["📱 تلگرام", "📷 اینستاگرام", "🔗 لینک"].map((item, idx) => (
              <button key={idx} className="px-4 py-2 bg-white border border-gray-200 rounded-xl text-xs font-medium text-gray-600 hover:bg-blue-50 hover:border-blue-200 hover:text-blue-600 transition-all">
                {item}
              </button>
            ))}
          </div>
        </div>

        {/* Related Posts */}
        <div>
          <h2 className="text-xl font-black text-gray-900 mb-6">مقالات مرتبط</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {otherPosts.map((p) => (
              <Link key={p.id} href={`/blog/${p.slug}`} className="group bg-white rounded-2xl overflow-hidden border border-gray-100 hover:shadow-lg transition-all">
                <div className="aspect-[16/10] overflow-hidden">
                  <img src={p.image} alt={p.title} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" loading="lazy" />
                </div>
                <div className="p-4">
                  <h3 className="text-sm font-bold text-gray-800 line-clamp-2 group-hover:text-blue-600 transition-colors leading-6">{p.title}</h3>
                  <span className="text-xs text-gray-400 mt-2 block">{p.date}</span>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </article>

      <Footer />
    </div>
  );
}
