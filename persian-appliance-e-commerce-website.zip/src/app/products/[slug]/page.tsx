"use client";

import { useState } from "react";
import { use } from "react";
import Link from "next/link";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import ProductCard from "@/components/ProductCard";
import { SAMPLE_PRODUCTS } from "@/lib/constants";
import { formatPriceToman, toFarsiNumber, calculateDiscount } from "@/lib/utils";

export default function ProductDetailPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = use(params);
  const product = SAMPLE_PRODUCTS.find((p) => p.slug === slug) || SAMPLE_PRODUCTS[0];
  const [selectedImage, setSelectedImage] = useState(0);
  const [activeTab, setActiveTab] = useState<"specs" | "features" | "reviews">("specs");
  const [quantity, setQuantity] = useState(1);
  const discount = calculateDiscount(product.price, product.discountPrice);
  const relatedProducts = SAMPLE_PRODUCTS.filter((p) => p.id !== product.id).slice(0, 4);

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />

      {/* Breadcrumb */}
      <div className="bg-white border-b border-gray-100">
        <div className="max-w-7xl mx-auto px-4 py-4">
          <div className="flex items-center gap-2 text-sm text-gray-500 flex-wrap">
            <Link href="/" className="hover:text-blue-600 transition-colors">صفحه اصلی</Link>
            <svg className="w-3.5 h-3.5 rotate-180" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7"/></svg>
            <Link href="/products" className="hover:text-blue-600 transition-colors">محصولات</Link>
            <svg className="w-3.5 h-3.5 rotate-180" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7"/></svg>
            <Link href={`/products?category=${product.categorySlug}`} className="hover:text-blue-600 transition-colors">{product.category}</Link>
            <svg className="w-3.5 h-3.5 rotate-180" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7"/></svg>
            <span className="text-gray-800 font-medium truncate max-w-[200px]">{product.name}</span>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 py-8">
        {/* Product Main */}
        <div className="bg-white rounded-2xl border border-gray-100 p-6 md:p-8 mb-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 lg:gap-12">
            {/* Gallery */}
            <div>
              <div className="relative aspect-square rounded-2xl overflow-hidden bg-gray-50 mb-4">
                <img
                  src={product.images[selectedImage]}
                  alt={product.name}
                  className="w-full h-full object-cover"
                />
                {discount > 0 && (
                  <div className="absolute top-4 right-4 px-3 py-1.5 bg-red-500 text-white text-sm font-black rounded-xl">
                    {toFarsiNumber(discount)}% تخفیف
                  </div>
                )}
                {product.isNew && (
                  <div className="absolute top-4 left-4 px-3 py-1.5 bg-green-500 text-white text-sm font-bold rounded-xl">
                    جدید
                  </div>
                )}
              </div>
              <div className="flex gap-3">
                {product.images.map((img, idx) => (
                  <button
                    key={idx}
                    onClick={() => setSelectedImage(idx)}
                    className={`w-20 h-20 rounded-xl overflow-hidden border-2 transition-all ${
                      idx === selectedImage ? "border-blue-500 shadow-lg" : "border-gray-200 hover:border-gray-300"
                    }`}
                  >
                    <img src={img} alt="" className="w-full h-full object-cover" />
                  </button>
                ))}
              </div>
            </div>

            {/* Info */}
            <div>
              <div className="mb-4">
                <span className="text-sm text-blue-600 font-medium">{product.category} | {product.brand}</span>
              </div>
              <h1 className="text-2xl md:text-3xl font-black text-gray-900 mb-4 leading-tight">{product.name}</h1>
              
              {/* Rating */}
              <div className="flex items-center gap-3 mb-6">
                <div className="flex items-center gap-1">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <svg key={star} className={`w-4 h-4 ${star <= Math.round(product.rating) ? 'text-yellow-400' : 'text-gray-200'}`} fill="currentColor" viewBox="0 0 20 20">
                      <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"/>
                    </svg>
                  ))}
                </div>
                <span className="text-sm text-gray-500">{toFarsiNumber(product.rating)} از ۵ ({toFarsiNumber(product.reviewCount)} نظر)</span>
              </div>

              <p className="text-gray-600 text-sm leading-7 mb-6">{product.shortDescription}</p>

              {/* Price */}
              <div className="bg-gray-50 rounded-2xl p-6 mb-6">
                {product.discountPrice ? (
                  <div>
                    <div className="flex items-center gap-3 mb-2">
                      <span className="text-lg text-gray-400 line-through">{formatPriceToman(product.price)}</span>
                      <span className="px-2 py-0.5 bg-red-100 text-red-600 text-xs font-bold rounded-lg">{toFarsiNumber(discount)}% تخفیف</span>
                    </div>
                    <span className="text-3xl font-black text-blue-600">{formatPriceToman(product.discountPrice)}</span>
                  </div>
                ) : (
                  <span className="text-3xl font-black text-gray-900">{formatPriceToman(product.price)}</span>
                )}
              </div>

              {/* Quick Info */}
              <div className="space-y-3 mb-6">
                <div className="flex items-center gap-3 text-sm">
                  <span className="text-green-500">✓</span>
                  <span className="text-gray-600">رنگ: <strong>{product.color}</strong></span>
                </div>
                <div className="flex items-center gap-3 text-sm">
                  <span className="text-green-500">✓</span>
                  <span className="text-gray-600">رده انرژی: <strong>{product.energyRating}</strong></span>
                </div>
                <div className="flex items-center gap-3 text-sm">
                  <span className="text-green-500">✓</span>
                  <span className="text-gray-600">گارانتی: <strong>{product.warranty}</strong></span>
                </div>
                <div className="flex items-center gap-3 text-sm">
                  {product.stock > 0 ? (
                    <>
                      <span className="text-green-500">✓</span>
                      <span className="text-green-600 font-medium">موجود در انبار ({toFarsiNumber(product.stock)} عدد)</span>
                    </>
                  ) : (
                    <>
                      <span className="text-red-500">✗</span>
                      <span className="text-red-600 font-medium">ناموجود</span>
                    </>
                  )}
                </div>
              </div>

              {/* Quantity & Add to Cart */}
              <div className="flex items-center gap-4 mb-6">
                <div className="flex items-center border border-gray-200 rounded-xl overflow-hidden">
                  <button onClick={() => setQuantity(Math.max(1, quantity - 1))} className="px-4 py-3 text-gray-600 hover:bg-gray-50 transition-colors">−</button>
                  <span className="px-4 py-3 font-bold text-gray-800 min-w-[50px] text-center">{toFarsiNumber(quantity)}</span>
                  <button onClick={() => setQuantity(Math.min(product.stock, quantity + 1))} className="px-4 py-3 text-gray-600 hover:bg-gray-50 transition-colors">+</button>
                </div>
                <button className="flex-1 py-3.5 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-xl transition-colors shadow-lg hover:shadow-xl flex items-center justify-center gap-2">
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z"/></svg>
                  افزودن به سبد خرید
                </button>
              </div>

              {/* Actions */}
              <div className="flex items-center gap-3">
                <button className="flex items-center gap-2 px-4 py-2.5 border border-gray-200 rounded-xl text-sm text-gray-600 hover:border-red-200 hover:text-red-500 hover:bg-red-50 transition-all">
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z"/></svg>
                  علاقه‌مندی
                </button>
                <button className="flex items-center gap-2 px-4 py-2.5 border border-gray-200 rounded-xl text-sm text-gray-600 hover:border-blue-200 hover:text-blue-500 hover:bg-blue-50 transition-all">
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z"/></svg>
                  مقایسه
                </button>
                <button className="flex items-center gap-2 px-4 py-2.5 border border-gray-200 rounded-xl text-sm text-gray-600 hover:border-green-200 hover:text-green-500 hover:bg-green-50 transition-all">
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8.684 13.342C8.886 12.938 9 12.482 9 12c0-.482-.114-.938-.316-1.342m0 2.684a3 3 0 110-2.684m0 2.684l6.632 3.316m-6.632-6l6.632-3.316m0 0a3 3 0 105.367-2.684 3 3 0 00-5.367 2.684zm0 9.316a3 3 0 105.368 2.684 3 3 0 00-5.368-2.684z"/></svg>
                  اشتراک
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Tabs */}
        <div className="bg-white rounded-2xl border border-gray-100 mb-8">
          <div className="border-b border-gray-100">
            <div className="flex overflow-x-auto">
              {[
                { key: "specs" as const, label: "مشخصات فنی" },
                { key: "features" as const, label: "ویژگی‌ها" },
                { key: "reviews" as const, label: `نظرات (${toFarsiNumber(product.reviewCount)})` },
              ].map((tab) => (
                <button
                  key={tab.key}
                  onClick={() => setActiveTab(tab.key)}
                  className={`px-8 py-4 text-sm font-medium whitespace-nowrap transition-all border-b-2 ${
                    activeTab === tab.key
                      ? "border-blue-600 text-blue-600"
                      : "border-transparent text-gray-500 hover:text-gray-700"
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </div>
          </div>

          <div className="p-6 md:p-8">
            {activeTab === "specs" && (
              <div className="max-w-2xl">
                <table className="w-full">
                  <tbody>
                    {Object.entries(product.specs).map(([key, value], idx) => (
                      <tr key={key} className={idx % 2 === 0 ? "bg-gray-50" : ""}>
                        <td className="px-4 py-3 text-sm font-medium text-gray-700 w-1/3">{key}</td>
                        <td className="px-4 py-3 text-sm text-gray-600">{value}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}

            {activeTab === "features" && (
              <div className="max-w-2xl space-y-3">
                {product.features.map((feature, idx) => (
                  <div key={idx} className="flex items-start gap-3 p-3 rounded-xl hover:bg-gray-50 transition-colors">
                    <div className="w-6 h-6 bg-blue-100 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                      <svg className="w-3.5 h-3.5 text-blue-600" fill="currentColor" viewBox="0 0 20 20"><path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd"/></svg>
                    </div>
                    <span className="text-sm text-gray-700 leading-6">{feature}</span>
                  </div>
                ))}
              </div>
            )}

            {activeTab === "reviews" && (
              <div className="max-w-2xl">
                <div className="text-center py-8">
                  <span className="text-4xl mb-4 block">💬</span>
                  <h3 className="text-lg font-bold text-gray-800 mb-2">نظرات مشتریان</h3>
                  <p className="text-sm text-gray-500 mb-4">اولین نفری باشید که نظر می‌دهید</p>
                  <button className="px-6 py-2.5 bg-blue-600 text-white text-sm font-bold rounded-xl hover:bg-blue-700 transition-colors">
                    ثبت نظر
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Related Products */}
        <div className="mb-8">
          <h2 className="text-xl font-black text-gray-900 mb-6">محصولات مرتبط</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {relatedProducts.map((p) => (
              <ProductCard key={p.id} product={p} />
            ))}
          </div>
        </div>
      </div>

      <Footer />
    </div>
  );
}
