"use client";

import { useState, useMemo } from "react";
import Link from "next/link";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import ProductCard from "@/components/ProductCard";
import SectionTitle from "@/components/SectionTitle";
import { CATEGORIES, SAMPLE_PRODUCTS } from "@/lib/constants";
import { toFarsiNumber } from "@/lib/utils";

type SortOption = "newest" | "price-asc" | "price-desc" | "popular" | "discount";

export default function ProductsPage() {
  const [selectedCategory, setSelectedCategory] = useState<string>("");
  const [sortBy, setSortBy] = useState<SortOption>("newest");
  const [priceRange, setPriceRange] = useState<[number, number]>([0, 100000000]);
  const [gridView, setGridView] = useState(true);
  const [filtersOpen, setFiltersOpen] = useState(false);

  const filteredProducts = useMemo(() => {
    let products = [...SAMPLE_PRODUCTS];
    if (selectedCategory) {
      products = products.filter((p) => p.categorySlug === selectedCategory);
    }
    products = products.filter((p) => {
      const price = p.discountPrice || p.price;
      return price >= priceRange[0] && price <= priceRange[1];
    });
    switch (sortBy) {
      case "price-asc":
        products.sort((a, b) => (a.discountPrice || a.price) - (b.discountPrice || b.price));
        break;
      case "price-desc":
        products.sort((a, b) => (b.discountPrice || b.price) - (a.discountPrice || a.price));
        break;
      case "popular":
        products.sort((a, b) => b.reviewCount - a.reviewCount);
        break;
      case "discount":
        products.sort((a, b) => b.discount - a.discount);
        break;
      default:
        break;
    }
    return products;
  }, [selectedCategory, sortBy, priceRange]);

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />

      {/* Breadcrumb */}
      <div className="bg-white border-b border-gray-100">
        <div className="max-w-7xl mx-auto px-4 py-4">
          <div className="flex items-center gap-2 text-sm text-gray-500">
            <Link href="/" className="hover:text-blue-600 transition-colors">صفحه اصلی</Link>
            <svg className="w-3.5 h-3.5 rotate-180" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7"/></svg>
            <span className="text-gray-800 font-medium">محصولات</span>
            {selectedCategory && (
              <>
                <svg className="w-3.5 h-3.5 rotate-180" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7"/></svg>
                <span className="text-gray-800 font-medium">
                  {CATEGORIES.find((c) => c.slug === selectedCategory)?.name}
                </span>
              </>
            )}
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 py-8">
        <div className="flex flex-col lg:flex-row gap-8">
          {/* Sidebar Filters */}
          <aside className={`lg:w-72 flex-shrink-0 ${filtersOpen ? 'block' : 'hidden lg:block'}`}>
            <div className="bg-white rounded-2xl border border-gray-100 p-6 sticky top-24">
              <h3 className="text-base font-bold text-gray-900 mb-6">فیلترها</h3>

              {/* Categories */}
              <div className="mb-6">
                <h4 className="text-sm font-bold text-gray-700 mb-3">دسته‌بندی</h4>
                <div className="space-y-2">
                  <button
                    onClick={() => setSelectedCategory("")}
                    className={`w-full text-right px-3 py-2 rounded-xl text-sm transition-all ${
                      !selectedCategory ? "bg-blue-50 text-blue-600 font-medium" : "text-gray-600 hover:bg-gray-50"
                    }`}
                  >
                    همه دسته‌بندی‌ها
                  </button>
                  {CATEGORIES.map((cat) => (
                    <button
                      key={cat.id}
                      onClick={() => setSelectedCategory(cat.slug)}
                      className={`w-full text-right px-3 py-2 rounded-xl text-sm transition-all flex items-center justify-between ${
                        selectedCategory === cat.slug ? "bg-blue-50 text-blue-600 font-medium" : "text-gray-600 hover:bg-gray-50"
                      }`}
                    >
                      <span className="flex items-center gap-2">
                        <span>{cat.icon}</span>
                        {cat.name}
                      </span>
                      <span className="text-xs text-gray-400">{toFarsiNumber(cat.count)}</span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Price Range */}
              <div className="mb-6">
                <h4 className="text-sm font-bold text-gray-700 mb-3">محدوده قیمت</h4>
                <div className="space-y-2">
                  {[
                    { label: "همه قیمت‌ها", range: [0, 100000000] as [number, number] },
                    { label: "زیر ۱۰ میلیون", range: [0, 10000000] as [number, number] },
                    { label: "۱۰ تا ۳۰ میلیون", range: [10000000, 30000000] as [number, number] },
                    { label: "۳۰ تا ۵۰ میلیون", range: [30000000, 50000000] as [number, number] },
                    { label: "بالای ۵۰ میلیون", range: [50000000, 100000000] as [number, number] },
                  ].map((item, idx) => (
                    <button
                      key={idx}
                      onClick={() => setPriceRange(item.range)}
                      className={`w-full text-right px-3 py-2 rounded-xl text-sm transition-all ${
                        priceRange[0] === item.range[0] && priceRange[1] === item.range[1]
                          ? "bg-blue-50 text-blue-600 font-medium"
                          : "text-gray-600 hover:bg-gray-50"
                      }`}
                    >
                      {item.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Energy Rating */}
              <div className="mb-6">
                <h4 className="text-sm font-bold text-gray-700 mb-3">رده انرژی</h4>
                <div className="flex flex-wrap gap-2">
                  {["A+++", "A++", "A+", "A"].map((rating) => (
                    <span key={rating} className="px-3 py-1.5 bg-green-50 text-green-700 text-xs font-medium rounded-lg cursor-pointer hover:bg-green-100 transition-colors">
                      {rating}
                    </span>
                  ))}
                </div>
              </div>

              {/* Clear Filters */}
              <button
                onClick={() => { setSelectedCategory(""); setPriceRange([0, 100000000]); }}
                className="w-full py-2.5 text-sm text-red-500 hover:bg-red-50 rounded-xl transition-colors font-medium"
              >
                پاک کردن فیلترها
              </button>
            </div>
          </aside>

          {/* Products Grid */}
          <div className="flex-1">
            {/* Toolbar */}
            <div className="bg-white rounded-2xl border border-gray-100 p-4 mb-6 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
              <div className="flex items-center gap-3">
                <button onClick={() => setFiltersOpen(!filtersOpen)} className="lg:hidden px-4 py-2 bg-gray-100 rounded-xl text-sm font-medium text-gray-700">
                  فیلترها
                </button>
                <span className="text-sm text-gray-500">
                  {toFarsiNumber(filteredProducts.length)} محصول
                </span>
              </div>
              <div className="flex items-center gap-3">
                <select
                  value={sortBy}
                  onChange={(e) => setSortBy(e.target.value as SortOption)}
                  className="px-4 py-2 bg-gray-50 border border-gray-200 rounded-xl text-sm text-gray-700 focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  <option value="newest">جدیدترین</option>
                  <option value="popular">محبوب‌ترین</option>
                  <option value="price-asc">ارزان‌ترین</option>
                  <option value="price-desc">گران‌ترین</option>
                  <option value="discount">بیشترین تخفیف</option>
                </select>
                <div className="flex border border-gray-200 rounded-xl overflow-hidden">
                  <button onClick={() => setGridView(true)} className={`p-2 ${gridView ? 'bg-blue-50 text-blue-600' : 'text-gray-400'}`}>
                    <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 20 20"><path d="M5 3a2 2 0 00-2 2v2a2 2 0 002 2h2a2 2 0 002-2V5a2 2 0 00-2-2H5zM5 11a2 2 0 00-2 2v2a2 2 0 002 2h2a2 2 0 002-2v-2a2 2 0 00-2-2H5zM11 5a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2V5zM11 13a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2v-2z"/></svg>
                  </button>
                  <button onClick={() => setGridView(false)} className={`p-2 ${!gridView ? 'bg-blue-50 text-blue-600' : 'text-gray-400'}`}>
                    <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 20 20"><path fillRule="evenodd" d="M3 4a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zm0 4a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zm0 4a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zm0 4a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1z" clipRule="evenodd"/></svg>
                  </button>
                </div>
              </div>
            </div>

            {/* Products */}
            {filteredProducts.length > 0 ? (
              <div className={gridView ? "grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-6" : "space-y-4"}>
                {filteredProducts.map((product) => (
                  gridView ? (
                    <ProductCard key={product.id} product={product} />
                  ) : (
                    <Link key={product.id} href={`/products/${product.slug}`} className="flex bg-white rounded-2xl border border-gray-100 overflow-hidden hover:shadow-lg transition-all group">
                      <div className="w-48 h-48 flex-shrink-0 overflow-hidden">
                        <img src={product.image} alt={product.name} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" loading="lazy" />
                      </div>
                      <div className="p-5 flex-1">
                        <span className="text-xs text-blue-600 font-medium">{product.category}</span>
                        <h3 className="text-base font-bold text-gray-800 mt-1 mb-2 group-hover:text-blue-600 transition-colors">{product.name}</h3>
                        <p className="text-sm text-gray-500 mb-3 line-clamp-2">{product.shortDescription}</p>
                        <div className="flex items-center gap-4">
                          {product.discountPrice ? (
                            <>
                              <span className="text-sm text-gray-400 line-through">{toFarsiNumber(product.price.toLocaleString())} تومان</span>
                              <span className="text-base font-black text-blue-600">{toFarsiNumber(product.discountPrice.toLocaleString())} تومان</span>
                            </>
                          ) : (
                            <span className="text-base font-black text-gray-800">{toFarsiNumber(product.price.toLocaleString())} تومان</span>
                          )}
                        </div>
                      </div>
                    </Link>
                  )
                ))}
              </div>
            ) : (
              <div className="bg-white rounded-2xl border border-gray-100 p-16 text-center">
                <span className="text-5xl mb-4 block">🔍</span>
                <h3 className="text-lg font-bold text-gray-800 mb-2">محصولی یافت نشد</h3>
                <p className="text-sm text-gray-500">فیلترهای خود را تغییر دهید یا دسته‌بندی دیگری را انتخاب کنید</p>
              </div>
            )}
          </div>
        </div>
      </div>

      <Footer />
    </div>
  );
}
