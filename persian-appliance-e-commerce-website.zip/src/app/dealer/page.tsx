"use client";

import { useState } from "react";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { PROVINCES } from "@/lib/constants";

export default function DealerPage() {
  const [form, setForm] = useState({
    companyName: "", contactName: "", phone: "", email: "",
    province: "", city: "", address: "", businessLicense: "",
    experience: "", storeInfo: "",
  });
  const [submitted, setSubmitted] = useState(false);
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      await fetch("/api/dealer", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(form) });
      setSubmitted(true);
    } catch { /* ignore */ }
    setLoading(false);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      <section className="bg-gradient-to-l from-blue-800 to-blue-900 py-16 md:py-24">
        <div className="max-w-7xl mx-auto px-4 text-center">
          <h1 className="text-4xl md:text-5xl font-black text-white mb-4">درخواست نمایندگی</h1>
          <p className="text-blue-200 max-w-lg mx-auto">به شبکه بزرگ نمایندگی‌های پارس‌تک بپیوندید و از مزایای همکاری با ما بهره‌مند شوید</p>
        </div>
      </section>

      {/* Benefits */}
      <section className="max-w-7xl mx-auto px-4 -mt-12 relative z-10 mb-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          {[
            { icon: "💰", title: "سود بالا", desc: "حاشیه سود رقابتی" },
            { icon: "🚚", title: "تحویل سریع", desc: "ارسال فوری از انبار" },
            { icon: "📢", title: "حمایت تبلیغاتی", desc: "پشتیبانی بازاریابی" },
            { icon: "🎓", title: "آموزش", desc: "دوره‌های آموزشی تخصصی" },
          ].map((item, idx) => (
            <div key={idx} className="bg-white rounded-2xl p-6 text-center border border-gray-100 shadow-lg">
              <span className="text-3xl mb-3 block">{item.icon}</span>
              <h3 className="text-sm font-bold text-gray-800 mb-1">{item.title}</h3>
              <p className="text-xs text-gray-500">{item.desc}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="max-w-3xl mx-auto px-4 pb-16">
        <div className="bg-white rounded-2xl p-8 md:p-10 border border-gray-100 shadow-sm">
          {submitted ? (
            <div className="text-center py-16">
              <span className="text-6xl mb-4 block">🎉</span>
              <h2 className="text-2xl font-black text-green-600 mb-3">درخواست شما با موفقیت ثبت شد</h2>
              <p className="text-gray-500 text-sm">کارشناسان ما ظرف ۴۸ ساعت آینده با شما تماس خواهند گرفت</p>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-6">
              <h2 className="text-xl font-black text-gray-900 mb-6">اطلاعات متقاضی</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">نام شرکت/فروشگاه *</label>
                  <input type="text" required value={form.companyName} onChange={(e) => setForm({ ...form, companyName: e.target.value })} className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500" placeholder="نام شرکت" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">نام و نام خانوادگی مدیر *</label>
                  <input type="text" required value={form.contactName} onChange={(e) => setForm({ ...form, contactName: e.target.value })} className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500" placeholder="نام مدیر" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">شماره تماس *</label>
                  <input type="tel" required value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500" dir="ltr" placeholder="09123456789" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">ایمیل</label>
                  <input type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500" dir="ltr" placeholder="email@example.com" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">استان *</label>
                  <select required value={form.province} onChange={(e) => setForm({ ...form, province: e.target.value })} className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500">
                    <option value="">انتخاب استان</option>
                    {PROVINCES.map((p) => <option key={p} value={p}>{p}</option>)}
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">شهر *</label>
                  <input type="text" required value={form.city} onChange={(e) => setForm({ ...form, city: e.target.value })} className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500" placeholder="نام شهر" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">شماره جواز کسب</label>
                  <input type="text" value={form.businessLicense} onChange={(e) => setForm({ ...form, businessLicense: e.target.value })} className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500" />
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">آدرس فروشگاه</label>
                <textarea rows={2} value={form.address} onChange={(e) => setForm({ ...form, address: e.target.value })} className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 resize-none" />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">سابقه فعالیت در حوزه لوازم خانگی</label>
                <textarea rows={3} value={form.experience} onChange={(e) => setForm({ ...form, experience: e.target.value })} className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 resize-none" placeholder="سابقه کاری و فعالیت‌های قبلی خود را شرح دهید..." />
              </div>
              <button type="submit" disabled={loading} className="w-full py-3.5 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-xl transition-colors shadow-lg disabled:opacity-50">
                {loading ? "در حال ارسال..." : "ارسال درخواست نمایندگی"}
              </button>
            </form>
          )}
        </div>
      </section>

      <Footer />
    </div>
  );
}
